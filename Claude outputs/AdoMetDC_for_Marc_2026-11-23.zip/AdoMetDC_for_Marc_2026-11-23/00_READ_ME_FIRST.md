# AdoMetDC–ODC fusions: where this stands, and the two runs I'm asking for

Tui, 22 November 2026. Everything here comes from the `stuy__adometdc` FOLDTRACE run.
`aim1_settings_used.json` and the `models/` folder were read only and never modified.

**What I'm asking for is in `01_hpc_jobs/`.** The rest is context, and you only need as
much of it as you want.

---

## 1. The finding

**AdoMetDC fused to an ODC-family decarboxylase is far more common than the literature
says.** Your 1,000-hit run contained 23 such proteins. Searching UniParc directly on the
two Pfam domains, with no structure filter and no cap, returns **311 sequences**.

They are in **all three Archaeplastida lineages** — green algae and plants, red algae,
and a glaucophyte — plus alveolates well beyond *Plasmodium* (~40 dinoflagellates,
*Chromera*, a ciliate), a brown alga, and two CRuMs.

⚠️ **Two tiers of evidence, and I keep them separate.** The 23 passed the TM ≥ 0.5 fold
gate. The other 288 are on Pfam annotation alone — the UniParc search uses no structure
at all. I have not loosened your gate; I went around the 1,000 cap by asking a different
question.

**Novelty.** Your own search terms, run exhaustively (every query logged): the fusion is
described in *Plasmodium*, reported once in *Micromonas* (Green 2011), and counted
without identification as "3 plant sequences" in a supplementary legend of Volkov 2016.
Michael's 2017 *Biochem J* review — on gene fusion in polyamine metabolism — calls these
fusions rare and phylogenetically constrained and names only *Micromonas*. I have read
Michael 2011, Michael 2016, Michael 2017 and Fuell 2010 in full. All clean.

## 2. They are real genes, not merged gene models

This was the main worry, and I tested it against a case that **did** turn out to be an
artefact — a three-domain *Caenorhabditis* protein that proved to be two genes joined by
the predictor, its extra domains hanging off across the two largest introns in the model
(1,125 and 1,456 nt against a typical 39–62).

For the 23:
- **No junction intron is an outlier.** Each was compared against the other introns of
  the same gene and against the genome-wide distribution. *Galdieria*'s is 53 nt against
  a genome median of 50; several sit in the bottom tenth percentile.
- **Nine run through the junction unbroken**, five of them single-exon genes.
- **Four species had a second, independently annotated genome. All eight proteomes
  scanned return the fusion**, four of them as a non-identical sequence — i.e. rebuilt
  from scratch by a different group.
- ***Ceratopteris richardii* carries eight copies.**
- **The partner is always the same enzyme**, one step away in the same pathway, across
  lineages that diverged a billion years ago. Mis-annotation produces random neighbours.

## 3. The result I actually want your opinion on

**The AdoMetDC half is never degraded. The ODC half often is — and only outside the
green lineage.**

Your five prespecified sites, mapped onto all 23 fusions and all 590 standalone
proteins: Ser68 22/22, His243 22/22, Cys82 22/22, Glu247 21/21, all Fisher p = 1. One
loss anywhere (*Riccia* S229→F). These are ordinary, intact AdoMetDC enzymes.

The ODC half is another matter. **Every confident substitution at the 13 human-ODC
functional residues falls in a red alga or *Percolomonas* — 8 of 8 proteins. None of the
18 green-lineage fusions has one.** Red-algal fusions with models are now 7 of 7
degraded, across four classes.

The lost residues sit at pLDDT 70–91 and are spread over three or four of seven site
groups, so this is not a low-confidence patch. The domains stay close to full length and
keep their fold; they are retained, not truncated.

**An NJ tree puts the red-algal fusions together and *Percolomonas* elsewhere**, so the
ODC half has died at least twice independently. ⚠️ Bootstrap is 0% on every set tested,
including the apicomplexan one, so that tree carries no support — and its alignment
filter dropped several degraded sequences for having short Pfam spans. I am treating it
as suggestive and not chasing a maximum-likelihood version.

## 4. Two things I have already talked myself out of

**Fusion does not cause catalytic-site loss.** Standalone 25/590 (4.2%) vs fused 3/101
(3.0%), Fisher p = 0.785, within-phylum permutation 0.717. An earlier version using a
length-based proxy for "fused" gave p = 0.004; the proxy was wrong.

**Fusion does not change the putrescine regulatory site.** Leu13→Arg and Phe111→Lys look
striking in the fusions until you notice 133 standalone proteins do the same. Everything
collapses under the within-phylum permutation. One borderline survivor at Glu15
(p = 0.0055), which I am treating as a lead, not a result.

## 5. What the runs are for

ODC only works as a dimer — its active sites are built across the subunit interface
(Fuell 2010). AdoMetDC is also a dimer. So **one dimerisation of a fusion protein may
serve both halves at once**, which would be a structural reason these two particular
enzymes keep getting fused. And if a degraded ODC half still forms that interface while
having lost its chemistry, it is being kept as a structural element rather than as an
enzyme — which is the prozyme logic in a different system.

I tried to test this from sequence conservation and it does not work: the AdoMetDC
halves are catalytically perfect yet share only ~22% of human interface residues, so
surface conservation cannot distinguish a live domain from a dead one. It has to be done
on structures.

I have run all seven on AlphaFold Server as a pilot (one seed each). **What I am asking
for is the four-seed version**, as in your HEPN paper — a single seed can be confidently
wrong about a domain arrangement, and I would rather know that before building anything
on it.

## 6. What is in this package

| | |
|---|---|
| `01_hpc_jobs/` | **the eight homodimer FASTAs, a README, and `RUN_SPEC.md` — this is the ask** |
| | `RUN_SPEC.md` is the precise version: stoichiometry, seeds, and exactly which outputs are needed |
| `02_results/` | the readable reports behind sections 1–4 |
| `03_tables/` | the per-protein tables |
| `RESEARCH_LOG.md` | the full running record; this survey is Thread 6 |

**A possible second batch, only if the first looks worth it:** roughly a hundred of the
311 have no AlphaFold DB model at all, which is why the tree had to drop *Galdieria* and
*Porphyra*. Folding ~25 of them — the red algae without models, plus one representative
each from the glaucophyte, brown algal, CRuMs and dinoflagellate lineages — would let
the whole set be analysed by one standard instead of two. I have not included those
sequences here; no point until the dimers say something.

## 7. One loose end, not a question for you

Michael 2011 (*Methods Mol Biol* 720:139) has now been read in full: no *Micromonas*, no
AdoMetDC-ODC fusion, nothing on the distribution. Its four "fusion" mentions are a fungal
SpdSyn-saccharopine dehydrogenase fusion, a *Vibrio* DABA AT/DC fusion, the abstract, and
a reference title. That was the last of the four reviews, so the novelty check is closed
as far as the literature can close it.

The Glu178 regulatory work is unaffected. One thing from this run that bears on it: of
the 65 standalone proteins that lost Glu178, **30 went to Asn** - the diatom pattern,
sitting in this survey's control group.
