# Dimer predictions — eight jobs

Each file holds **two identical copies** of one sequence. Run each as a homodimer.

**AlphaFold-Multimer (or AF3), four seeds per complex**, as in Zimmer 2026 *J Mol Biol*.
Please return the **PAE matrices** as well as the ranked models — the inter-chain PAE is
the whole point and the ranked model alone doesn't carry it.

| # | protein | organism | role | residues per chain |
|---|---|---|---|---|
| 01 | A0A1Y1HLG4 | *Klebsormidium nitens* | fusion, ODC half intact (13/13 residues) | 864 |
| 02 | A0A2V3IZY9 | *Gracilariopsis chorda* | fusion, ODC half degraded; species has no other complete ODC | 730 |
| 03 | A0A9C7PQ51 | *Galdieria partita* | fusion, ODC half degraded; species does keep a standalone ODC | 762 |
| 04 | C1E5E7 | *Micromonas commoda* | the fusion already reported (Green 2011) | 1019 |
| 05 | Q8IJ77 | *Plasmodium falciparum* | the known working bifunctional enzyme | 1419 |
| 06 | A0AAV8UQI0 | *Rhodosorus marinus* | **control** — standalone ODC, all 13 residues intact | 395 |
| 07 | P17707 | *Homo sapiens* | **control** — standalone AdoMetDC, a genuine dimer | 334 |
| 08 | P11926 | *Homo sapiens* | **control** — standalone ODC, the textbook homodimer | 461 |

## The question

ODC only works as a dimer: its two active sites are built across the subunit interface,
each from residues of both chains (Fuell 2010). Human AdoMetDC is also a dimer. So one
dimerisation of a fusion protein might serve both halves at once — a structural reason
these two particular enzymes keep getting fused.

And if a **degraded** ODC half still forms that interface despite having lost its
catalytic residues, it is being kept as a structural element rather than as an enzyme.

## What to look at

1. **Inter-chain PAE first.** If it is high the arrangement is a guess, whatever the
   per-residue pLDDT says.
2. Then: do the two ODC halves form the canonical ODC interface — in particular, do
   Lys69 of one chain and Cys360 of the other come together? Do the two AdoMetDC halves
   also pair?
3. Compare 01 (intact) against 02 and 03 (degraded).

## What the one-seed pilot already showed

All seven ran once on AlphaFold Server. **Every job failed a 10 Å mean inter-chain PAE
gate**, so no geometry was interpretable. Two things were still informative:

- The **standalone ODC control reached 9.2 Å** once disordered residues were dropped
  (ipTM 0.72) — the method does find a real dimer when there is one.
- Per-domain, the fusions with an **intact** ODC half paired at their ODC domains
  (block PAE 10.9 and 11.4, ipTM 0.55 and 0.49) at about the confidence of the real ODC
  dimer, while the **degraded** ones did not pair at all (block PAE ~30, ipTM 0.18). The
  AdoMetDC halves did not pair in any fusion.

If that holds up with four seeds it argues **against** the degraded halves being retained
as interfaces — they appear to have lost the pairing along with the chemistry.

## Correction from the pilot

Job 07 was originally *Adiantum* AdoMetDC. That was a poor control: plant AdoMetDC is
fully active as a **monomer** (Fuell 2010), so it was never going to dimerise, and it
didn't (ipTM 0.13). It has been replaced with human P17707, and human ODC P11926 added
as a second known-good positive control.
