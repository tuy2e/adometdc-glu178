# Run specification

Written so it can be handed straight to whoever (or whatever) sets up the jobs.
Everything needed is in this folder.

## Inputs

Eight FASTA files, `01_*.fasta` through `08_*.fasta`. **Each file already contains two
identical copies of one sequence**, labelled `_chainA` and `_chainB`. Run each file as a
single prediction of a **homodimer (A2 stoichiometry)**. Do not split the records into
separate monomer runs, and do not combine files.

| job | accession | organism | chain length | total residues (×2) |
|---|---|---|---|---|
| 01 | A0A1Y1HLG4 | *Klebsormidium nitens* | 864 | 1728 |
| 02 | A0A2V3IZY9 | *Gracilariopsis chorda* | 730 | 1460 |
| 03 | A0A9C7PQ51 | *Galdieria partita* | 762 | 1524 |
| 04 | C1E5E7 | *Micromonas commoda* | 1019 | 2038 |
| 05 | Q8IJ77 | *Plasmodium falciparum* | 1419 | 2838 |
| 06 | A0AAV8UQI0 | *Rhodosorus marinus* | 395 | 790 |
| 07 | P17707 | *Homo sapiens* | 334 | 668 |
| 08 | P11926 | *Homo sapiens* | 461 | 922 |

Jobs 06–08 are controls and are small; job 05 is the largest at 2,838 residues.

## What to run

- **AlphaFold-Multimer**, or **AlphaFold 3** if that is what is installed. Either is fine;
  please say which was used.
- **Four random seeds per complex**, as in Zimmer 2026 *J Mol Biol* — a single seed can
  settle on a wrong inter-domain arrangement and report high per-residue confidence while
  doing so. Four independent seeds are what make the arrangement checkable.
- Default MSA and template settings. No custom templates and no constraints.
- 8 jobs × 4 seeds = **32 predictions**.

## What to return

For every seed of every job, not just the top-ranked one:

1. **The predicted structure** — mmCIF or PDB, with both chains and their original chain
   IDs preserved.
2. **The PAE matrix**, as the raw JSON or array. This is the part that matters most and
   the one most often dropped: the inter-chain block of the PAE decides whether the
   predicted arrangement means anything at all. A ranked model without its PAE cannot be
   used here.
3. **Per-residue pLDDT** (in the B-factor column is fine).
4. **ipTM and pTM** per model, and the ranking scores.
5. Whatever log states the software version, database version and the seeds used.

A directory per job, a subdirectory per seed, is ideal. Nothing needs renaming.

## What will be done with it

The inter-chain PAE is averaged whole-chain and then restricted to each domain pair
(ODC-half × ODC-half, AdoMetDC-half × AdoMetDC-half). Anything above a 10 Å mean
inter-chain PAE is treated as uninterpretable and its geometry is not used. Models that
pass are superposed onto the human ODC dimer (1D7K chains A+B) and the human AdoMetDC
dimer (1MSV chains A+B) to ask whether the canonical interfaces are reproduced —
specifically whether Lys69 of one chain and Cys360 of the other come together as they do
in a real ODC dimer.

Agreement across the four seeds is the acceptance criterion, not the confidence of any
single model.

## Context for whoever is setting this up

ODC is an obligate homodimer: each of its two active sites is built across the subunit
interface, from residues of both chains. AdoMetDC is also a dimer. These eight proteins
include five in which an AdoMetDC domain and an ODC-family domain are fused into one
chain, and the question is whether one dimerisation of such a protein satisfies both
halves at once.

In three of the five fusions the ODC half is intact; in two it has lost most of its
catalytic residues while keeping its fold. If a degraded half still forms the interface,
it is retained as a structural element rather than as an enzyme. Jobs 06–08 are known
dimers and exist to show the method detects an interface when one is really there.

## Pilot already run, for comparison

Seven of these ran once each on AlphaFold Server (one seed). **All failed the 10 Å gate**,
so nothing was interpretable. Two observations survive and are worth checking against the
four-seed results:

- The standalone ODC control reached 9.2 Å mean inter-chain PAE once residues below
  pLDDT 70 were dropped, with ipTM 0.72.
- Per domain pair, fusions with an intact ODC half paired at their ODC domains (block PAE
  10.9 and 11.4; ipTM 0.55 and 0.49) at roughly the confidence of the real ODC dimer,
  while the two with a degraded ODC half did not (block PAE ≈ 30; ipTM 0.18). The
  AdoMetDC halves did not pair in any fusion.

An eighth job was added and one control replaced after that pilot: the original AdoMetDC
control was *Adiantum*, and plant AdoMetDC is fully active as a monomer, so it could not
have formed a dimer. Human P17707 replaced it, and human ODC P11926 was added.
