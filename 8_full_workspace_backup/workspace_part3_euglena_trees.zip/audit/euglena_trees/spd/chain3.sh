#!/bin/bash
cd /home/claude/eug/spd
for h in h1b_crke_only h1c_cr_euglenozoa; do iqtree2 -s spdE_trim.aln -m LG+R6 -g $h.nwk -T 1 -seed 1 -redo -pre C_$h > C_${h}_run.log 2>&1; done
cat spdE.treefile C_h1_crke.treefile C_h2_crrho.treefile C_h3_stdino.treefile C_h4_lineage.treefile C_h1b_crke_only.treefile C_h1c_cr_euglenozoa.treefile > au7_spdE.nwk
while pgrep -f "^iqtree2 .*-pre H_kin_E$" >/dev/null; do sleep 20; done
iqtree2 -s spdE_trim.aln -m LG+R6 -z au7_spdE.nwk -n 0 -zb 10000 -au -T 2 -seed 1 -redo -pre au7_spdE > au7_spdE_run.log 2>&1
echo done > chain3.done
