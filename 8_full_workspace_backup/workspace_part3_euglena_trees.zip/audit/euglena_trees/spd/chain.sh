#!/bin/bash
cd /home/claude/eug/spd
while pgrep -f "^iqtree2 .*-pre spdE$" >/dev/null; do sleep 20; done
for h in h1_crke h2_crrho h3_stdino h4_lineage; do
  iqtree2 -s spdE_trim.aln -m LG+R6 -g $h.nwk -T 1 -seed 1 -redo -pre C_$h > C_${h}_run.log 2>&1
done
cat spdE.treefile C_h1_crke.treefile C_h2_crrho.treefile C_h3_stdino.treefile C_h4_lineage.treefile > au_spdE.nwk
# wait for the AdoMetDC ML run to free its core before the 2-thread AU test
while pgrep -f "^iqtree2 .*-pre expE$" >/dev/null; do sleep 20; done
iqtree2 -s spdE_trim.aln -m LG+R6 -z au_spdE.nwk -n 0 -zb 10000 -au -T 2 -seed 1 -redo -pre au_spdE > au_spdE_run.log 2>&1
echo CHAIN_DONE > chain.done
