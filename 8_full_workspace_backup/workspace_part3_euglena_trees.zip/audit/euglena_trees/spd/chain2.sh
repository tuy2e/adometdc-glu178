#!/bin/bash
# extra constrained searches, run on the core freed by the AdoMetDC ML run
while pgrep -f "^iqtree2 .*-pre expE$" >/dev/null; do sleep 20; done
cd /home/claude/eug/adomet/au && iqtree2 -s ../expE_trim.aln -m Q.pfam+R7 -g h_kin_E.nwk -T 1 -seed 1 -nstop 20 -redo -pre H_kin_E > H_kin_E_run.log 2>&1
cd /home/claude/eug/spd
for h in h1b_crke_only h1c_cr_euglenozoa; do iqtree2 -s spdE_trim.aln -m LG+R6 -g $h.nwk -T 1 -seed 1 -redo -pre C_$h > C_${h}_run.log 2>&1; done
echo done > chain2.done
