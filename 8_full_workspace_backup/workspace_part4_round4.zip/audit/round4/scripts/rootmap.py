import json
B='C:\\Users\\Soniya\\Documents\\GitHub\\adometdc-glu178\\'
M={'1_reports':['RESEARCH_LOG.md','stramenopile_Glu178_step1_results.md','stramenopile_Glu178_steps2-6_results.md','WOW_findings_publication_assessment.md'],
'3_data\\alignments':['adometdc_main_trimmed.aln','adometdc_no_kinetoplastids.aln','adometdc_no_pocket_columns.aln','spermidine_synthase_trimmed.aln'],
'3_data\\annotations':['clade_sets.json','human_position_to_alignment_column.json','ncbi_expansion_residue_calls.json','spermidine_synthase_labels.json','tree_sequence_groups.json','uniprot_set_residue_calls.json'],
'3_data\\sequences':['adometdc_187_tree_input.fa','euglena_gracilis_from_tblastn.fa','euglena_tblastn_queries.fa','spdsyn_blast_queries.fa','spermidine_synthase_142.fa'],
'3_data\\test_results':['ancestral_expA_site109.json','ancestral_H_li_site109.json','ancestral_H_sar_site109.json','ancestral_main_tree_site178.json','ancestral_P_li_site109.json','ancestral_P_sar_site109.json','AU_au10C60.iqtree','AU_au7.iqtree','AU_au7NP.iqtree','AU_au8C60.iqtree','AU_auE.iqtree','AU_auNP.iqtree','AU_spermidine_synthase.iqtree','C60_tree_report.iqtree','main_tree_report.iqtree','RESULTS_round2.md','RESULTS_spdsyn.md'],
'3_data\\trees':['constrained_H_li.treefile','constrained_H_sar.treefile','constrained_P_li.treefile','constrained_P_sar.treefile','main_tree_C60_PMSF.treefile','main_tree_Qpfam_R7_consensus.contree','main_tree_Qpfam_R7.treefile','main_tree_rooted.nwk','spermidine_synthase_tree.treefile'],
'4_scripts':['spdsyn_analyze_spd.py','spdsyn_condense.py','spdsyn_reduce.py','strameno_analyze178.py','strameno_asr178.py','strameno_build_master.py','strameno_expand_map_new.py','strameno_expand_prep_expand.py','strameno_expand_treefig_exp.py','strameno_expand2_asr_any.py','strameno_expand2_asr_exp.py','strameno_expand2_asr_site.py','strameno_expand2_biparts.py','strameno_expand2_make_hyp.py','strameno_pairmap.py','strameno_parse_uniprot_tsv.py','strameno_prep_tree.py','strameno_treefig.py'],
'5_literature':['novelty_reading_list.md','TECHNICAL_RECORD_litsearch.md'],
'6_side_project_bodo_prozyme':['activation_interface_mapping_Bodo.md','AlphaFold_modeling_package.md','dead_paralog_literature_review.md','TECHNICAL_RECORD_bodo_prozyme.md'],
'6_side_project_bodo_prozyme\\alphafold_inputs':['Bodo_AdoMetDC_heterodimer.fasta','Bodo_DHS_heterodimer.fasta'],
'6_side_project_bodo_prozyme\\prozyme_trees_and_suggestions':['ADOMETDC_RESEARCH_PACKET.md','kinetoplastid_engine_residues.tsv','kinetoplastid_tree.nwk','prozyme_phylogeny.nwk','README_my_suggestions.md'],
'7_background_notes':['AdoMetDC_everything_we_know.md','Marc_meeting_summary_2026-11-05.md','methods_walkthrough_for_Marc.md','RESEARCH_PACKAGE_for_Thursday.md']}
pairs=[]
for d,fs in M.items():
    for f in fs: pairs.append((B+f, B+d+'\\'+f))
pairs.append((B+'README (1).md', B+'README.md'))
json.dump(pairs,open('/home/claude/r4/rootpairs.json','w'))
allp=[p for pr in pairs for p in pr]
print(len(pairs), len(allp))
for i in range(0,len(allp),50): print(json.dumps(allp[i:i+50]))
