#!/bin/bash
jobs=(
"cd /home/claude/r4/spd && iqtree2 -s spdR4.trim.aln -m LG+R6 -g h1c_creuglenozoa.nwk -T 1 -seed 1 -redo -pre C_h1c_creuglenozoa > C_h1c_run.log 2>&1"
"cd /home/claude/r4/spd && iqtree2 -s spdR4.trim.aln -m LG+R6 -g h3_stdino.nwk -T 1 -seed 1 -nstop 30 -redo -pre C_h3_stdino > C_h3_run.log 2>&1"
"cd /home/claude/r4/spd && iqtree2 -s spdR4.trim.aln -m LG+R6 -g h4_lineage.nwk -T 1 -seed 1 -nstop 30 -redo -pre C_h4_lineage > C_h4_run.log 2>&1"
"cd /home/claude/r4/spd && iqtree2 -s spdR4.trim.aln -m LG+R6 -g h2_crrho.nwk -T 1 -seed 1 -nstop 30 -redo -pre C_h2_crrho > C_h2_run.log 2>&1"
)
for j in "${jobs[@]}"; do
  while [ "$(pgrep -c -f '^iqtree2 ')" -ge 2 ]; do sleep 15; done
  echo "$(date +%H:%M) start: $j" >> /home/claude/r4/queue.log
  bash -c "$j" &
  sleep 5
done
wait
echo "$(date +%H:%M) ALL DONE" >> /home/claude/r4/queue.log
