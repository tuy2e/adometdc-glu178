#!/bin/bash
# run constrained searches, at most 2 iqtree2 processes at a time
jobs=(
"cd /home/claude/r4/adomet && iqtree2 -s r4_trim.aln -m Q.pfam+R7 -g c_L.nwk -T 1 -seed 1 -nstop 20 -redo -pre C_L > C_L_run.log 2>&1"
"cd /home/claude/r4/spd && iqtree2 -s spdR4.trim.aln -m LG+R6 -g h1_crkeeu.nwk -T 1 -seed 1 -redo -pre C_h1_crkeeu > C_h1_run.log 2>&1"
"cd /home/claude/r4/spd && iqtree2 -s spdR4.trim.aln -m LG+R6 -g h1b_crke.nwk -T 1 -seed 1 -redo -pre C_h1b_crke > C_h1b_run.log 2>&1"
"cd /home/claude/r4/spd && iqtree2 -s spdR4.trim.aln -m LG+R6 -g h1c_creuglenozoa.nwk -T 1 -seed 1 -redo -pre C_h1c_creuglenozoa > C_h1c_run.log 2>&1"
"cd /home/claude/r4/spd && iqtree2 -s spdR4.trim.aln -m LG+R6 -g h3_stdino.nwk -T 1 -seed 1 -redo -pre C_h3_stdino > C_h3_run.log 2>&1"
"cd /home/claude/r4/spd && iqtree2 -s spdR4.trim.aln -m LG+R6 -g h4_lineage.nwk -T 1 -seed 1 -redo -pre C_h4_lineage > C_h4_run.log 2>&1"
"cd /home/claude/r4/spd && iqtree2 -s spdR4.trim.aln -m LG+R6 -g h2_crrho.nwk -T 1 -seed 1 -redo -pre C_h2_crrho > C_h2_run.log 2>&1"
)
for j in "${jobs[@]}"; do
  while [ "$(pgrep -c -f '^iqtree2 ')" -ge 2 ]; do sleep 15; done
  echo "$(date +%H:%M) start: $j" >> /home/claude/r4/queue.log
  bash -c "$j" &
  sleep 5
done
wait
echo "$(date +%H:%M) ALL DONE" >> /home/claude/r4/queue.log
