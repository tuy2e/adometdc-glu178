# Full fact-check log (started 27-28 Oct 2026). Keep updating; survives context compaction.
Working copies of edited files: /root/audit/fix/  (apply edits there, then commit to device)
Device root: ~/Downloads/unlabeled_fp_search/AdoMetDC_project/
Staged originals: /mnt/user-data/uploads/unlabeled_fp_search/AdoMetDC_project/

## Already done (27 Oct) and committed
- 9_ README + tree figure + tree_leaf_table + neighborhood tsv; 8_ WOW_findings.md; 8_ lid_results_summary.md;
- 1_reports/Phe285 guide (never-mutated fixes only); 1_reports/putrescine site dependence (F7/F223 + never-mutated lines only)

## Leads from subagents (partial, they hit a usage limit) - VERIFY before using
- drugs_and_data.md ~line 12: says Genz-644131 'cured some mice infected with T. b. brucei STIB 795'; Barker 2009 abstract: cured LAB 110 EATRO; STIB 795 only extended survival (6.75 -> >30 days). Other Barker numbers OK.
- Bale&Ealick 2010 (PMC2847442) Table 1: E. coli SpeD = class 1a?? (agent said 'type 1a (tetramer, metal ion)'); class 1b = B. subtilis, T. maritima, A. aeolicus (NOT M. jannaschii). VERIFY.
- prokaryotic_evolution.md: cites 'Structure of E. coli AdoMetDC (Ekstrom 2001)' -> E. coli SpeD P0A7F6 has no PDB structure (agent); DOI given = human paper PMID 11583148. VERIFY.
- Potato PDB 1MHM real; human 1I72/1I7B/1JEN real; Thermotoga 1TLU/1TMI real (agent).
- Citation ID errors: PMC2556000 (Pak1-LC8, wrong), PMC2846215 (TdT, wrong, already noted in file as wrong), PMID 12228245 (SERA, wrong; Graham 2002 = PMID 11980912).

## Per-file results (append below)

### Verified facts (reusable)
- Bale 2008 PMC2646671 Table: WT processing +Put 5-8x, decarboxylation +Put 4x; E178Q decarboxylation -Put = 4 (comparable to WT +Put) -> 'stuck on' OK; D174N no Put binding; putrescine aliphatic chain stacks against Phe285 and Phe111 (full text).
- Volkov 2016 eLife (PMC5201418) full text: "Prozyme is only found in the trypanosomatids." (quote OK; cite Volkov 2016)
- Toms 2004 (PMID 15150268) abstract: T. maritima Ser55, His68, Cys83 structurally conserved; prokaryotic dimer fold similar to eukaryotic protomer -> evolutionary link.
- Stanley 1991 (PMID 1917972): subunits 67 and 267 aa; E8Q/E11Q process but catalytically inactive; C82A no activity; E15Q/E61Q/E67Q/E247Q minimal effect.
- UniProt P0A7F6 E. coli SpeD: cleavage 111-112 (Lys111|Ser112), pyruvoyl Ser112, His117 proton acceptor (processing), 140 proton donor. => 'E. coli uses Lys at the Glu67 position' OK.
- UniProt Q9WZC3 Thermotoga: pyruvoyl Ser63, His68 proton acceptor, 83 proton donor. Ser55 NOT annotated in UniProt (it is in Toms 2004).
- 14 named proteins: P0DMN7 mouse Amd1; O02655 C. elegans smd-1; P91931 Drosophila SamDC; Q96286 Arabidopsis SAMDC1; Q04694 potato; Q587A7 T. brucei; O76240 T. cruzi; Q587B3 T. brucei prozyme-like; P0A7F6 E. coli; Q9WZC3 Thermotoga; O34426 B. subtilis; Q57763 M. jannaschii; P21182 yeast SPE2.

### File: 1_reports/AdoMetDC FOLDTRACE results across organisms.md (in progress)
- Chunk 2 table: matches 14_organisms call files (all rows OK incl. TM values).
- Chunk 3 numbers OK (658/651/559/15/77/7; Ser68 2 oddities; Cys82 1A 1R). His243: 5 non-His (S x2, P, Q, L) - 'a few fragments' imprecise.
- Line 49: 'Thermotoga His68 and Ser55 matched UniProt annotations' -> Ser55 is from Toms 2004, not UniProt; fix wording.
- Line 71: 'free-living' unverified; quote OK -> add (Volkov et al. 2016).
- Line 69: 'deep-branching protist' -> NCBI: Eukaryota incertae sedis.
- Line 102, 118: add T. cruzi F285H (Beswick 2006).
- Files section: file names wrong (no AdoMetDC_ prefix).
- Line 15 + Chunk 4: groups assigned from species names -> recompute with NCBI lineages (in progress).
- DONE edits for FOLDTRACE results report (groups verified: all 1000 agree with NCBI; plant D174 kept 2/157; stramenopile N178 not in oomycetes (H/Q); bacteria phyla by NCBI; Toms 2004 for Ser55; Volkov 2016 quote; Beswick F285H; file names).
- DONE edits for 1_reports/Trypanosome prozyme pseudoenzyme.md: 'almost-identical' -> 25-30% identical; removed unverified 'first clear case'; polyamines NOT absent in humans (fixed); 110-fold T. cruzi = Willert&Phillips 2009 (not 2007); Leishmania not tested in 2009; DHS 3,000x (Nguyen 2013); Barker strains (STIB795 survival / LAB110 EATRO cured); antizyme absence cited Patel 2018; PDB titles/resolutions verified at RCSB (6BM7 = UTSAM568, 2.98 A; no T. cruzi/Leishmania AdoMetDC PDB); Crithidia is a trypanosomatid (fixed); PubMed search links -> PMID links; Wikipedia cites replaced by primary sources; quote fixed to verbatim Willert 2007.
### Verified (prozyme): eLife 2016 S27-G30, G30-P31 cis->trans, b7/b8 3-residue register vs b6, h1 S7-R19, interface 3,200 A2, Table1 0.48/9.7/2.6e3/3.2e3; Velez 2013 L8 L10 M11 M13; Willert 2008 essential/limiting/translational; Xiao 2013 dcAdoMet; Patel 2018 dual circuit + antizyme/uORF absent; Kafkova 2017; Volkov 2017 400k/13 classes/>10-fold; Wu 2008 SMS N-term AdoMetDC-like (PMID 18367445); UniProt lengths/locus tags; O76240 Cys100 donor, Ser250/His263 acceptors.
### RCSB EC 4.1.1.50 entries (40): 1I72,1I79,1I7B,1I7C,1I7M,1JEN,1JL0,1MHM,1MSV,1TLU,1TMI,1VR7,2III,3DZ2-7,3EP3-9,3EPA,3EPB,3H0V,3H0W,3IWB,3IWC,3IWD,5TVF,5TVM,5TVO,6BM7,9P1H,9P7Q,9PBB
- DONE edits for 1_reports/Phe285 putrescine site guide.md: E67Q little effect (engine 'any residue dead' wrong); E. coli is type 1a tetramer metal-requiring (not class 2/octamer/'fills slot'); type 1b B.subtilis/Thermotoga/Aquifex dimer, activator not known; Arabidopsis Phe285 = His291 (not Ala289); S229T keeps processing but greatly reduced activity (not 'keeps function'); K80A wording per UniProt (10%/20x unverified, removed); E11K verified Stanley 1994 PMID 8132508; Glu256 kept in trypanosomes (not degenerate); Ser113 not conserved in plants/tryps; distance 16-20A unverified -> Bale wording; motifs corrected w/ sequences; Toms Ser55; 'two billion years' removed; outdated 'not yet run' lines updated; plants/Arabidopsis logic fixed.
