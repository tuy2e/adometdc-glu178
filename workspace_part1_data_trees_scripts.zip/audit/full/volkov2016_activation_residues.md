# Volkov 2016 (eLife, PMC5201418) — AdoMetDC activation mechanism residues (T. brucei numbering)
Extracted from full text, 4 Nov 2026. These are the residues the Bodo/Pcon sequences must be checked against.

## Mechanism in one paragraph
Monomeric TbAdoMetDC is AUTOINHIBITED: its own N-terminal residues S27–G30 sit in the active site (F28 π-stacks the catalytic Y243), held by a **cis** G30–P31 peptide bond. Prozyme binding triggers: (1) **cis→trans isomerization of P31**, ejecting S27–G30 and docking the N-terminal **h1 helix (S7–R19)** into the dimer interface; (2) a **β7/β8 "pyruvoyl β-sheet" register slip** (residues ~87–179 move 8–15 Å); (3) ordering of the **β6–h8 connector (H130–E138)**. Net result: active site opens, catalytic **C100** (=Hs C82) repositions → up to ~1000–1200× activation.

## A. ACTIVE-enzyme residues — does the Bodo/Pcon ACTIVE enzyme have the activatable architecture?
- **P31** — THE conformational-switch proline (cis→trans). Volkov tracks this across the tree: present in trypanosomatids, fungi, Naegleria, Dictyostelium; LOST in plants & animals. **Most diagnostic single residue.**
- **h1 activation residues L8, L10, M11, M13** (Velez 2013) — insert into interface; trypanosomatid-conserved, absent in human.
- **F20** — edge-to-face stack with prozyme-repositioned W137.
- **S27, F28, E29, G30** — autoinhibitory segment (F28 π-stacks Y243).
- **C100** — catalytic (Hs C82 equivalent); must be present in the ACTIVE copy.
- **β6–h8 connector: W137, M146, R154** — W137A/M146A cripples activation (Table 1). R154 H-bonds prozyme D171'.
- **168(I/V)DSDHY173 motif** (trypanosomatid-specific): **I168, D169, H172** — D169 reaches across interface (salt bridge to prozyme K156'/H163', H-bond Y152'); H172 = novel putrescine site. I164, Y176 part of the β-flip.
- **Y243** — active-site ligand residue (the one prozyme LACKS).

## B. PROZYME (dead copy) residues — does the Bodo/Pcon DEAD copy have the activator interface?
- **M148', Y152'** — mutagenesis-validated: prozyme M148'A/Y152'A forms heterodimer but FAILS to activate (Table 1). Core interface.
- **K156', H163'** — salt bridge to AdoMetDC D169.
- **D171'** — H-bond to AdoMetDC R154.
- **Scaffolding β15' R305'–H309'** — H-bonds AdoMetDC β15 (R336–E340); the rigid platform that nucleates heterodimerization.
- Prozyme putrescine site (Put'): **E42', W126', D195', D282'** (prozyme binds putrescine in its β-sheet pocket).
- Prozyme LACKS: pyruvoyl (no self-processing), Y243 equivalent, helices h9–h11, strand β10.

## Evolutionary framing from the paper (important & honest)
- The eukaryotic AdoMetDC gained a **dimerization domain** (not in bacteria); this "single step" is argued to enable the whole allosteric scheme.
- P31 + the activation-capable architecture are **ancestral to trypanosomatids** (found in fungi/protists), BUT the specific 16-aa N-terminal activation sequence and the IDSDHY motif are described as **trypanosomatid-specific / not conserved in other species.**
- Bodo saltans is a **free-living kinetoplastid, sister to trypanosomatids** — Volkov did NOT examine it. So whether Bodo has these trypanosomatid-defining activation features is exactly the open question. This analysis tests it.
