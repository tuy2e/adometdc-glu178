# Shared brief for every fact-check agent (read this fully first)

## Why this exists
Tuy is an undergraduate doing research on human S-adenosylmethionine decarboxylase (AdoMetDC, UniProt P17707) with Prof. Marc Zimmer. An AI assistant wrote these notes earlier. Some contained errors written from memory, for example:
- calling a euglenid a "trypanosomatid";
- saying Phe285 was "never mutated in any organism", when Beswick et al. 2006 (PMID 16784231) made F285H in T. cruzi AdoMetDC.

Tuy's rule is that **nothing may rest on memory**. Every factual claim has to be checked against a primary database or the cited paper. You are a fact-checker. **Do NOT edit any file.** Report findings only.

## What counts as a claim to check
Check every checkable statement:
- numbers (fold changes, kcat, percentages, counts, residue numbers, PDB IDs, resolutions);
- what a mutation did;
- what was or was not tested ("never mutated", "first", "only", "all", "unique");
- organism names, their group or lineage, and their common names;
- lifestyle claims ("free-living", "parasite", "predatory");
- who said what (author, year, journal, PMID/PMC/DOI correct, and does the cited paper actually support the sentence);
- quoted text (does the quote exist in the source?);
- database facts (UniProt features/annotations, PDB entries).

General textbook background can be checked against UniProt function text or a review in PMC (Bale & Ealick 2010, PMC2847442). If it can't be checked, label it.

## Tools you must use (the cloud shell has NO internet to NCBI/UniProt)
Use the browser tool `mcp__remote-devices__Claude_Browser__javascript_tool` with `{"action":"javascript_exec","tabId":"seed","text":"<JS>"}`. If it is deferred, load it first with ToolSearch query `select:mcp__remote-devices__Claude_Browser__javascript_tool`.

The page origin is rest.uniprot.org, and `fetch()` works there for:
- **NCBI E-utilities** `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/`, covering:
  - PubMed: esearch, esummary, efetch with rettype=abstract;
  - PMC full text: `efetch.fcgi?db=pmc&retmode=xml&id=<numeric PMC id>`, then parse with DOMParser and search the body text;
  - Taxonomy: esearch/efetch with db=taxonomy.
- **UniProt REST** `https://rest.uniprot.org/uniprotkb/<ACC>.json` (or `.txt`), and search.

Rules for the browser:
- **Never navigate the tab** and never open other sites.
- Keep each JS call's returned value under ~15,000 characters. Slice the text, or return only the regex matches with ~300 characters of context.
- **Rate limit:** wait at least 1.5 s between NCBI requests (`await new Promise(r=>setTimeout(r,1500))`). On HTTP 429, wait 5 s and retry, up to 3 times.

Working snippets:
```js
const E='https://eutils.ncbi.nlm.nih.gov/entrez/eutils/';
// search PubMed
(await (await fetch(E+'esearch.fcgi?db=pubmed&retmode=json&retmax=10&term='+encodeURIComponent('Beswick[Author] AND AdoMetDC'))).json()).esearchresult.idlist
// abstracts (text)
(await (await fetch(E+'efetch.fcgi?db=pubmed&rettype=abstract&retmode=text&id=16784231')).text()).slice(0,6000)
// PMC full text search
const x=await (await fetch(E+'efetch.fcgi?db=pmc&retmode=xml&id=2646671')).text(); const b=(new DOMParser().parseFromString(x,'text/xml').querySelector('body')||{}).textContent||''; b.match(/.{0,300}Phe285.{0,300}/g)
// UniProt
const u=await (await fetch('https://rest.uniprot.org/uniprotkb/P17707.json')).json(); JSON.stringify(u.comments.filter(c=>c.commentType==='FUNCTION')).slice(0,4000)
// NCBI taxonomy lineage + common names
const t=await (await fetch(E+'efetch.fcgi?db=taxonomy&retmode=xml&id=75058')).text(); t.slice(0,3000)
```

## Already verified, so don't redo these (reuse them)
- `/root/audit/full/citations_resolved.tsv` holds the PubMed/PMC metadata (authors, year, journal, title) for every PMID, PMC and DOI found in the notes. **Known WRONG identifiers:**
  - PMC2556000 is a Pak1-LC8 paper, not AdoMetDC.
  - PMC2846215 is a terminal deoxynucleotidyl transferase paper.
  - PMID 12228245 is a Plasmodium SERA paper. Graham et al. 2002 JBC is really PMID 11980912.
- `/root/audit/ncbi_taxonomy.tsv` holds NCBI lineages for the organisms in the Foldseek hits.
- UniProt P17707 mutagenesis features (exact): F7A no effect [11583147]; E8Q loss of activity, normal putrescine-stimulated processing; E11Q loss of activity and of putrescine-stimulated processing; E15Q little effect; C49A little effect; S50A 17% decrease in activity; E61Q little effect; S66A 38% decrease, slight reduction in processing; E67Q little effect; S68A loss of catalytic activity and processing; S69A 24% decrease; K80A greatly reduced catalytic activity, no putrescine-stimulated processing; C82A loss of activity, greatly reduced putrescine-stimulated processing; F223A no effect [11583147]; C226A little effect; S229A loss of processing; S229C greatly reduced processing; S229T greatly reduced catalytic activity but little effect on processing; H243A/E greatly reduced activity and processing; H243F/Y loss of processing; E247Q little effect; E249Q little effect.
- Bale et al. 2008 (PMID 19053272, PMC2646671) abstract: D174N does not bind putrescine; E178Q and E256Q bind weakly with no cooperativity; putrescine binding reorganizes Phe285, Phe315, Tyr318 and Phe320 and the 312–320 loop. Full text: "The aliphatic chain of putrescine stacks against Phe285 and Phe111."
- Beswick et al. 2006 (PMID 16784231): T. cruzi AdoMetDC; putrescine stimulates kcat/Km 27-fold; S111R reduced and F285H enhanced catalytic efficiency; F7 and T245 are important for putrescine stimulation.
- Willert et al. 2007 (PMID 17485680, PMC1895940) abstract: "trypanosomatids uniquely contain both a functional AdoMetDC and a paralog designated prozyme"; the heterodimer stimulates T. brucei AdoMetDC 1,200-fold.
- Bennett et al. 2002 (PMID 12463749): potato AdoMetDC is a monomer and fully active without putrescine; Leu13/Arg18, Phe111/Arg114, Asp174/Val181 and Phe285/His294 (human/potato) mimic putrescine.
- Tolbert et al. 2001 (PMID 11583147): Phe7, Phe223 and Glu247 side chains and the Leu65 carbonyl bind and position ligands; Cys82, Ser229 and His243 sit near the methionyl group.
- Bale et al. 2009 (PMID 19527050): cation–π interaction of the ligand with Phe7/Phe223; the substrate binding rate depends greatly on Phe7/Phe223.
- Hanfrey et al. 2002 (PMID 12205086): a conserved small uORF in the plant AdoMetDC 5′ leader represses translation.

## Output format (your final message, no file edits)
For EACH assigned file give a section with:
1. **WRONG**: line number; exact short quote; why (evidence = source ID plus a ≤25-word verbatim quote from the source); exact replacement text in plain, simple English.
2. **UNSOURCED/UNVERIFIABLE**: line; quote; what you tried; proposed safer wording (or "delete").
3. **Citation problems** (wrong PMID/DOI/author/year/journal, or a cited paper that doesn't support the sentence): line; quote; correct citation.
4. **Verified OK**: a count, plus 3–5 examples with evidence IDs.

Be strict but fair: wording that is a fair simplification of the source is OK. Flag a claim only when a reader would be misled. Prefer concrete corrected text Tuy can paste. Don't invent sources. If you cannot access full text, say so, and judge from the abstract only.
