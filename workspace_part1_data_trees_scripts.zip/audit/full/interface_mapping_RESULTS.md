# Activation-interface mapping onto Bodo/Paratrypanosoma dead copies — RESULTS
4 Nov 2026. Alignment: /root/audit/bodo/pcon_check.aln (Human, Tb active+dead, Bodo active+dead, Pcon active+dead). Script: /root/audit/full/map_interface.py. T. brucei numbering validated against Volkov 2016 (P31=P, C100=C, L8/L10/M11/M13, W137, D169, H172, prozyme W126'/M148'/Y152'/D195'/D282' all land correctly).

## PART 1 — AdoMetDC

### A. Does the Bodo/Pcon ACTIVE enzyme keep the "activatable" architecture? → YES
| Residue (Tb#) | Role | Human | Tb_ACT | Bodo_ACT | Pcon_ACT | verdict |
|---|---|---|---|---|---|---|
| **P31** | cis→trans switch proline (THE diagnostic) | T (absent) | P | **P** | **P** | **retained in free-living Bodo + Pcon; absent in human** |
| L8/L10/M11/M13 | h1 activation helix (Velez) | — (no N-ext) | L/L/M/M | I/L/M/M | V/L/M/M | retained (L10,M11,M13 exact) |
| F28 | autoinhibitory, π-stacks Y243 | F | F | F | F | retained |
| S27/E29/G30 | autoinhibitory segment | F/E/G | S/E/G | S/E/G | S/E/G | retained |
| C100 | catalytic Cys (Hs C82) | C | C | C | C | retained (active copies intact) |
| W137/M146 | β6–h8 connector (W137A/M146A kills activation) | S/F | W/M | W/M | W/M | retained |
| D169 | reaches across to prozyme (salt bridge) | N | D | D | D | retained |
| H172 | novel putrescine site in h1 pocket | C | H | H | H | retained |
| Y243 | active-site ligand residue | F | Y | F | F | aromatic retained (F, like human) |

→ The free-living Bodo and basal Paratrypanosoma **active** enzymes carry the full prozyme-activation-compatible architecture, including the P31 conformational switch that **human lacks.**

### B. Does the Bodo/Pcon DEAD copy keep the activator-interface? → LARGELY YES
| Prozyme residue (Tb#) | Role | Tb_DEAD | Bodo_DEAD | Pcon_DEAD | verdict |
|---|---|---|---|---|---|
| **M148'** | interface; M148'A/Y152'A abolishes activation | M | **M** | **M** | **retained** |
| **Y152'** | interface; mutagenesis-validated | Y | **Y** | **Y** | **retained** |
| D171' | H-bond to AdoMetDC R154 | D | D | D | retained |
| K156' | salt bridge to AdoMetDC D169 | K | K | K | retained |
| H163' | salt bridge to AdoMetDC D169 | H | K (basic) | S | partial |
| E42'/W126'/D195'/D282' | prozyme putrescine pocket | E/W/D/D | E/W/D/D | E/W/D/D | **fully retained** |
| R305'/H309' | scaffolding β15' edge | R/H | C/E | R/S | variable (peripheral) |

→ The **experimentally-validated** activator residues (M148', Y152', D171', K156') and the prozyme putrescine pocket are conserved in the free-living Bodo and basal Pcon dead copies. Only the peripheral β15' edge is variable.

### INTERPRETATION (honest)
Both halves of the Volkov-2016 activation machinery — the activatable architecture on the active enzyme (esp. the **P31 switch**) and the validated interface on the dead copy (**M148', Y152'**) — are conserved in free-living *Bodo saltans* and basal *Paratrypanosoma*. This **predicts the prozyme activation mechanism predates the trypanosomatid parasites** (option "a" from the lit review: the weak-enzyme-needs-a-dead-partner logic is ancestral), and refines Volkov's statement that these features are "trypanosomatid-specific" — they are in fact kinetoplastid-wide, present in a free-living relative.

### CAVEATS (must state)
1. Sequence conservation predicts but does NOT prove function — needs the biochemistry (express Bodo enzyme ± dead copy, measure activity).
2. P31 presence ≠ proof the cis-autoinhibition operates identically (needs structure).
3. Pcon sequences are partial (reconstructed from BLAST) → Pcon calls weaker than Bodo.
4. Retention of M148'/Y152' is consistent with, not proof of, an activator role.

## PART 2 — DHS (deoxyhypusine synthase)
Alignment /root/audit/dhstree/dhs7.aln; human DHS numbering (P49366, 369 aa) validated (K329=catalytic nucleophile, K287/H288/W327 land correctly). Script /root/audit/full/map_dhs.py. NB: no DHS heterotetramer structure exists, so (unlike AdoMetDC) the dead-copy "interface" is not residue-defined in the literature — what is testable is the Nguyen-2013 signature: active copy keeps catalytic Lys; dead copy LOSES it but KEEPS substrate-binding residues.

| Hs# | role | Hs | Bodo_ACT | Bodo_DEAD | Tb_DHSc | Tb_DHSp(dead) | Leish_ACT | Leish_DEAD |
|---|---|---|---|---|---|---|---|---|
| **K329** | **catalytic nucleophile** | K | **K** | **Y (lost)** | K | L (lost) | K | L (lost) |
| K287 | covalent intermediate | K | K | **K (kept)** | K | K | K | K |
| H288 | spd/NAD binding | H | H | **H (kept)** | H | H | H | H |
| N106 | NAD/spd binding | N | N | **N (kept)** | N | N | N | N |
| D238 | NAD binding | D | D | **D (kept)** | D | D | D | D |
| D243 | spd binding | D | E | D (kept) | E | D | S | D |
| D316 | spd/covalent | D | D | A (lost) | D | E | D | V |
| E323 | spd binding | E | E | D | E | A (lost) | E | D |
| W327 | spd/covalent | W | W | H (lost) | W | N (lost) | W | C |

### DHS interpretation
Bodo's DHS pair shows the **same architecture as the experimentally-validated T. brucei DHSc/DHSp**: the active copy (Bodo_DHS_active) keeps the catalytic Lys K329 + full binding set; the dead copy (Bodo_DHS_DEAD) has **lost K329 (→Y)** but **retains substrate-binding residues N106, D238, K287, H288** — exactly Nguyen 2013's signature ("lacks the catalytic Lys despite containing many putative substrate-binding residues"). So Bodo's DHS dead paralog is a bona fide prozyme-type dead copy, not random decay.
CAVEAT: no DHS complex structure exists → cannot map the specific activation-interface residues as for AdoMetDC; the rigorous claim is the catalytic-death + binding-retention pattern.
