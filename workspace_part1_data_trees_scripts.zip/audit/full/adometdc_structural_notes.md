# AdoMetDC — structural & mechanistic facts (verified notes)

Primary source read in full: **Bale & Ealick 2010, "Structural biology of S-adenosylmethionine decarboxylase," Amino Acids 38:451–460** (PMC2847442). All facts below are from that review's full text unless another citation is given. Each PDB ID still to be re-verified against RCSB directly (task 24).

## 1. What AdoMetDC is / does
- S-adenosylmethionine decarboxylase (AdoMetDC; EC 4.1.1.50). Human gene **AMD1**, UniProt **P17707**.
- Decarboxylates S-adenosylmethionine (SAM/AdoMet) → decarboxylated SAM (dcSAM), the **aminopropyl donor** for spermidine and spermine synthesis. Committed, rate-limiting step; tightly regulated.
- **Pyruvoyl-dependent**, NOT PLP-dependent — one of a small number of pyruvoyl-dependent decarboxylases. The pyruvoyl group is generated from the protein's own backbone.

## 2. Autoprocessing (how the pyruvoyl cofactor is made)
- Synthesized as a single proenzyme chain; self-cleaves (serinolysis) at an internal Ser.
- In human numbering the cleavage is at **Glu67–Ser68**. **[CORRECTED per UniProt P17707 + PDB chain ranges]** The proenzyme splits into a **β chain = residues 1–67** (N-terminal part) and an **α chain = residues 68–334** (C-terminal part). The **pyruvoyl group sits at the N-terminus of the α chain** (generated from Ser68), NOT the β chain. (My earlier draft had this backwards.)
- Mechanism (UniProt): "non-hydrolytic serinolysis" — the Ser68 side-chain hydroxyl oxygen becomes the C-terminus of the β chain; the rest of Ser68 undergoes oxidative deamination → ammonia + the pyruvoyl group capping the α-chain N-terminus.
- **Ser229** and **His243** participate in processing; the H243A mutant was trapped as the **ester intermediate** (structure 1JL0, 1.5 Å).
- Mature human enzyme = **heterotetramer of two α + two β chains** (i.e. (αβ)₂), per UniProt.

## 3. Catalytic mechanism (decarboxylation)
- Pyruvoyl group forms a Schiff base with the substrate's α-amino group; acts as electron sink for decarboxylation (like PLP would, but protein-derived).
- **His243 = catalytic base** (protonates/abstracts; in processing and catalysis).
- **Cys82 = catalytic acid** that protonates Cα after decarboxylation, controlling reprotonation stereochemistry. Mutating it (C82A) cripples turnover.
- Fidelity/turnover: wild-type performs **~15,000 catalytic turnovers** before an occasional transamination side-reaction inactivates the enzyme; **C82A drops to ~143** turnovers before inactivation (Cys82 enforces correct reprotonation). [numbers from the review]

## 4. Sulfonium / substrate recognition — the exceptional "cation-π" part
- The substrate's positively charged **sulfonium** group is recognized by a **cation-π sandwich** between two phenylalanines: **Phe7 and Phe223** (human). The review cites this interaction as worth **~4.5 kcal/mol** of binding energy.
- **Glu247** hydrogen-bonds/orients the adenine; **Phe223**, **Phe6**, **Glu67** also in substrate binding pocket (Table 2).
- This aromatic sandwiching of a sulfonium is a structurally distinctive recognition mode.

## 5. Putrescine activation (the "second site")
- Human (and trypanosomatid) AdoMetDC is allosterically **activated by putrescine**, which binds a buried acidic pocket ~16–20 Å from the active site and speeds both processing and decarboxylation.
- Human putrescine-binding residues (from the broader literature, to re-verify): Asp174, Glu178, Glu256, Glu15, Thr176, Ser113, Phe111; Lys80 relay; β-sheet loop closes over it.
- **Plant (potato)** enzyme does NOT need putrescine: it has internal **Arg18 and Arg114** that structurally mimic the putrescine charge (built-in activator).

## 6. Classification across life (review Table 1) — and METALS
Two broad classes, four/five subgroups:
- **Class 1a** — many Gram-negative bacteria + some archaea (e.g. **E. coli** SpeD). (β/α)4 **tetramer**. **Requires a metal ion (Mg2+)** for activity — the only AdoMetDC group with a structural/catalytic metal requirement. Processing uses the metal instead of putrescine.
- **Class 1b** — Gram-positive bacteria + some archaea (e.g. *B. subtilis*, *T. maritima*, *A. aeolicus*). **Dimer**. No known activator (no metal, no putrescine).
- **Class 2a** — plants (e.g. **potato**). Monomer-type fold (eukaryotic 4-layer αββα sandwich, internal pseudo-two-fold from gene duplication+fusion). Uses built-in Arg residues (no putrescine, no metal).
- **Class 2b-I** — animals/humans. Eukaryotic fold, dimer; **putrescine-activated**.
- **Class 2b-II** — trypanosomatid parasites (*T. brucei*, *T. cruzi*). **Heterodimer** of an active subunit + a catalytically dead paralog ("**prozyme**") that activates it (~1000×+). (This is the parasite drug-target angle.)

=> So "does it have metals?" — YES but only the **class 1a bacterial/archaeal** enzymes (E. coli-type); eukaryotic (human, plant) and most other AdoMetDCs are **metal-free**, using putrescine or built-in Arg instead.

## 7. The fold / evolution
- Eukaryotic AdoMetDC fold = **four-layer αββα sandwich** with internal pseudo-twofold symmetry → arose by **gene duplication and fusion** of an ancestral single-domain (prokaryotic-type) unit.
- Prokaryotic class-1 enzymes are the single-domain ancestral version (tetramer/dimer).

## 8. Solved structures named in the review (to re-verify on RCSB, task 24)
- **Human**: 1I7B (first human structure), **1MSV = S68A proenzyme** (non-cleaving, used as Marc's reference), **1JL0 = H243A ester intermediate**, 1JEN, plus putrescine / inhibitor complexes.
- **Potato (class 2a)**: 1MHM (2.3 Å).
- **Thermotoga maritima (class 1b)**: 1TLU. Catalytic set His68/Cys83/Ser55 (Table 2).
- **Aquifex aeolicus (class 1b)**: 2III. Catalytic set His69/Cys84/Thr56.
- Potato catalytic set: His249/Cys87/Ser236.
- **No heterodimeric parasite (prozyme) crystal structure existed as of this review** — modeled only. (Re-check RCSB for anything newer, e.g. the T. brucei complex.)

## Table 2 conserved residues (human numbering), from the review
- Processing: **His243, Cys82, Ser229** (+ Glu11 region).
- Substrate binding: **Glu247, Phe223, Phe6, Glu67**.
- Catalytic acid/base pair: **Cys82 (acid) / His243 (base)**; **Phe7 + Phe223** sulfonium cation-π.

---
### TO VERIFY NEXT (do not state as fact until checked)
1. Full current RCSB list for EC 4.1.1.50 incl. 2016 T. brucei prozyme complex (Volkov eLife — PDB?) and any 2023–2026 entries.
2. Exact turnover numbers (15,000 / 143) — confirm against the primary kinetics paper, not just the review.
3. Human putrescine-site residue list — confirm against a human putrescine-complex structure paper.
4. Recent (2023–2026) literature = "what's new".
5. Human/animal regulation (AMD1): uORF, antizyme, protein stability, cancer.
