# AdoMetDC — every experimental PDB structure (EC 4.1.1.50)

Source: RCSB search API + data GraphQL, retrieved 4 Nov 2026 (desktop browser). Query = EC lineage 4.1.1.50, experimental only. **Total = 40 entries.** Every field below is straight from RCSB (organism, method, resolution, release date, bound ligands). No E. coli / archaeal class-1a entry exists.

## NEWEST — "what's new" (2025)
| PDB | Title | Organism | Res (Å) | Released | Ligands |
|---|---|---|---|---|---|
| **9P1H** | **100K** human AdoMetDC | Homo sapiens | 1.81 | 2025-09-17 | PUT (putrescine), TRS, GOL |
| **9P7Q** | **273K** human AdoMetDC | Homo sapiens | 2.21 | 2025-09-17 | PUT, TRS, CL |
| **9PBB** | **293K** human AdoMetDC | Homo sapiens | 2.17 | 2025-09-17 | PUT, TRS |

→ A **multi-temperature X-ray series** of the human enzyme (100 K cryo, 273 K, 293 K near-physiological), all with putrescine bound. Multi-temperature crystallography is done to see **conformational dynamics / flexible regions that are frozen out at 100 K** — i.e. how the enzyme actually moves at body-ish temperature. This is the most recent AdoMetDC structural work and is about dynamics, not a new ligand. (Primary paper to confirm by PMID — task 25.)

## The parasite prozyme heterodimer (corrects the 2010 review, which said none existed)
| PDB | Title | Organism | Res (Å) | Released | Key ligand |
|---|---|---|---|---|---|
| 6BM7 | T. brucei AdoMetDC/**prozyme heterodimer** + pyrimidineamine inhibitor UTSAM568 | T. brucei (927) | 2.98 | 2018-01-03 | DY7 (inhibitor), PUT |
| 5TVF | T. brucei AdoMetDC/**prozyme heterodimer** + inhibitor **CGP 40215** | T. brucei (927) | 2.42 | 2017-01-11 | CGQ (inhibitor), PUT |
| 5TVM | T. brucei AdoMetDC/**prozyme heterodimer** (apo) | T. brucei (927) | 2.41 | 2017-01-11 | PUT |
| 5TVO | T. brucei AdoMetDC-Δ26 **monomer** (active subunit alone) | T. brucei | 1.48 | 2016-12-28 | NA (sodium) |

→ These are the Phillips/Ealick trypanosome prozyme-complex structures (Volkov 2016 eLife = 5TV*; Patel/McCloskey 2018 = 6BM7). The "Inactive S-adenosylmethionine decarboxylase prozyme" chain is explicitly annotated. So a **heterodimeric parasite structure now exists** — important update vs Bale & Ealick 2010.

## METALS — the honest answer
- **Only ONE** of the 40 entries has bound metal ions: **2III** (*Aquifex aeolicus*, a class-1b bacterial enzyme) — **MG (Mg²⁺) + CA (Ca²⁺)**.
- **No human, potato, T. maritima or T. brucei** structure has a catalytic metal. Their only heteroatoms are buffer/cryo (TRS tris, GOL glycerol, EDO/PGE/PG4 glycols, CL/NA ions, PYR = the modeled pyruvoyl group) or putrescine (PUT) and inhibitors.
- The review's "**class 1a (E. coli-type) requires Mg²⁺**" claim rests on **biochemistry, not a crystal structure** — there is **no E. coli (SpeD) structure in the PDB at all** (confirms the research-note correction). So: eukaryotic AdoMetDC (human, plant) is **metal-free**; a Mg²⁺ requirement is a bacterial/archaeal (class-1) feature, and the only structural glimpse of metal is A. aeolicus 2III.

## Prokaryotic / archaeal (class 1) structures
| PDB | Organism | Res | Note |
|---|---|---|---|
| 1VR7 | T. maritima | 1.2 | proenzyme, ultra-high-res |
| 1TLU | T. maritima | 1.55 | proenzyme (class 1b) |
| 1TMI | T. maritima | 1.7 | **S63A** non-processing mutant |
| 3IWB | T. maritima | 2.06 | processed form |
| 3IWC | T. maritima | 1.9 | + SAM methyl ester (SMM) |
| 3IWD | T. maritima | 1.9 | + 5'-dimethyl-thioadenosine |
| 2III | A. aeolicus | 2.3 | proenzyme — **Mg + Ca bound** |

## Plant (class 2a)
| 1MHM | Solanum tuberosum (potato) | 2.3 | the plant structure; uses built-in Arg, no putrescine |

## Human (class 2b-I) — the big inhibitor / mutant collection
- **Foundational:** 1JEN (1999, first human, 2.25Å); 1I7B (SAM methyl ester, 1.9Å); 1I72/1I79/1I7M (nucleoside & amidinohydrazone inhibitors); **1I7C (+ MGBG, methylglyoxal bis-guanylhydrazone — the classic anticancer AdoMetDC inhibitor)**; **1I7M (+ CGP/SAM486A-type amidinoindanone)**.
- **Processing mechanism:** **1MSV (S68A proenzyme — Marc's reference)**; **1JL0 (H243A, ester intermediate, 1.5Å — traps self-processing)**.
- **Putrescine-site dissection (Bale 2008):** 3EP3/3EP6 (D174N ±SMM), 3EP4/3EP7 (E256Q), 3EP5/3EP8 (E178Q), 3EP9 (apo, no putrescine), 3EPA (E178Q+putrescine), 3EPB (E256Q+putrescine). → confirms putrescine-site residues **Asp174, Glu178, Glu256** are real (these are the ones mutated).
- **Sulfonium/cation-π (Ealick 2009):** 3DZ3 (**F223A** mutant + covalent SMM — tests the Phe223 cation-π), plus 8-substituted-adenosine inhibitor series 3DZ2/3DZ4/3DZ5/3DZ6/3DZ7, 3H0V/3H0W.

## Cross-checks this gives us (verified)
1. Marc's reference 1MSV = human S68A non-processing proenzyme, 1.75Å, Homo sapiens — confirmed.
2. His243 catalytic role confirmed by 1JL0 (H243A traps the ester intermediate → His243 needed to finish processing).
3. Phe223 cation-π role confirmed by 3DZ3 (F223A tested crystallographically).
4. Putrescine site residues D174/E178/E256 confirmed by the 3EP* mutant series.
5. No E. coli structure exists — metal requirement in class 1a is biochemical only.
