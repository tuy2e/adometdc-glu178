def parse(path):
    seqs={}; name=None
    for line in open(path):
        line=line.rstrip('\n')
        if line.startswith('>'):
            name=line[1:].strip(); seqs[name]=''
        elif name is not None:
            seqs[name]+=line.strip()
    return seqs
aln=parse('/root/audit/dhstree/dhs7.aln')
order=['Human_DHS_active','Bodo_DHS_active_88720','Bodo_DHS_DEAD_12440',
       'Tbrucei_DHSc_active','Tbrucei_DHSp_DEAD_inactive','Leish_DHS34_active','Leish_DHSL20_DEAD_inactive']
short={'Human_DHS_active':'Hs','Bodo_DHS_active_88720':'Bodo_ACT','Bodo_DHS_DEAD_12440':'Bodo_DEAD',
       'Tbrucei_DHSc_active':'Tb_DHSc','Tbrucei_DHSp_DEAD_inactive':'Tb_DHSp','Leish_DHS34_active':'Leish_ACT','Leish_DHSL20_DEAD_inactive':'Leish_DEAD'}
for n in order:
    if n not in aln: print('MISSING',n)
ref='Human_DHS_active'
def col_of(resnum):
    s=aln[ref]; c=0
    for i,ch in enumerate(s):
        if ch!='-':
            c+=1
            if c==resnum: return i
    return None
def refres(resnum):
    s=aln[ref].replace('-',''); return s[resnum-1] if 0<resnum<=len(s) else '?'
print('Human_DHS_active ungapped length =', len(aln[ref].replace('-','')))
pos=[(106,'N-NAD/spd'),(109,'S-spd'),(137,'E-NAD'),(238,'D-NAD'),(243,'D-spd'),
     (287,'K-covalent'),(288,'H-spd/NAD'),(316,'D-spd/cov'),(323,'E-spd'),
     (327,'W-spd/cov'),(329,'K-CATALYTIC*'),(342,'D-NAD')]
hdr='  Hs#  ref | '+' '.join('%-9s'%short[n] for n in order)
print(hdr); print('  '+'-'*len(hdr))
for resnum,label in pos:
    col=col_of(resnum); rr=refres(resnum)
    if col is None: print('  %4s out of range %s'%(resnum,label)); continue
    cells=[('%-9s'%aln[n][col]) for n in order]
    print('  %4d %s   | %s'%(resnum,rr,' '.join(cells))+'  <%s>'%label)
