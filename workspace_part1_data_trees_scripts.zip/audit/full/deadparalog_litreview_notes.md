# Dead-paralog (prozyme / pseudoenzyme) literature review — working notes
Verified from PubMed abstracts/full text, 4 Nov 2026. OA = open access (readable now); PAYWALL = flag for ILL.

## A. FUNCTION of the AdoMetDC prozyme — what the dead copy DOES (all OA)

**1. Willert, Fitzpatrick & Phillips 2007, PNAS 104:8275 — DISCOVERY** (PMC1895940, OA; PMID 17485680)
- Trypanosomatids uniquely have BOTH a functional AdoMetDC AND a paralog ("prozyme") that lost catalytic activity.
- Prozyme forms a high-affinity heterodimer with AdoMetDC that stimulates its activity **1,200-fold** (T. brucei).
- "prozyme has evolved to be a **catalytically dead but allosterically active subunit** of AdoMetDC" — an example of how regulators of multimeric enzymes evolve via **gene duplication + mutational drift**.

**2. Willert & Phillips 2009, Mol Biochem Parasitol 168:1 — conserved across species** (PMC2730992, OA; PMID 19523496)
- T. cruzi AdoMetDC/prozyme heterodimer = **110-fold** more active than homodimer; further stimulated by putrescine.
- Prozyme works by increasing **k_cat**; putrescine works by lowering **K_m** (two independent levers).
- Cross-species heterodimers (T. cruzi × T. brucei) are functional → prozyme activation is a **common, conserved mechanism** across trypanosomatids.

**3. Velez, Brautigam & Phillips 2013, JBC 288:5232 — the activation "handle"** (PMC3576127, OA; PMID 23288847)
- The **N-terminus of AdoMetDC (12 residues; key = Leu8, Leu10, Met11, Met13)** is essential for prozyme activation.
- These residues are **conserved in trypanosomatids but ABSENT in other eukaryotes that lack the prozyme mechanism** → co-evolved with the prozyme.
- Mutating them doesn't block heterodimer formation → they drive a **conformational change**, not binding.

**4. Volkov et al. 2016, eLife 5:e20198 — THE MECHANISM (most important)** (PMC5201418, OA; PMID 27977001)
- Monomeric T. brucei AdoMetDC is **auto-inhibited** by its own N-terminal sequence sitting in the active site.
- Prozyme heterodimerization **displaces that sequence** via a complex switch: **cis→trans proline isomerization + β-sheet reorganization + insertion of the N-terminal α-helix into the heterodimer interface** → activation.
- "the evolution of this intricate regulatory mechanism was **facilitated by the acquisition of the dimerization domain, a single step** that can account for the divergence of regulatory schemes in the AdoMetDC family."
- => The dead copy's job = a **conformational trigger that relieves autoinhibition**. Pure allostery; adds zero catalytic residues.

**5. Xiao et al. 2013, Mol Microbiol 88:846 — how much prozyme is made is itself regulated** (PMC3771639, OA; PMID 23634831)
- Prozyme expression is **translationally controlled** (3'UTR element; protein up, RNA flat on AdoMetDC inhibition).
- Prozyme protein level is **inversely proportional to dcAdoMet** (decarboxylated AdoMet, the reaction product) → product feedback.

**6. Patel et al. 2018, PLoS Pathog 14:e1007404 — dual feedback circuit** (PMC6221367, OA; PMID 30365568)
- Both **AdoMetDC protein itself** AND **dcAdoMet** suppress prozyme translation.
- AdoMetDC has an **enzyme-activity-INDEPENDENT function** (an active-site-dead mutant still regulates prozyme) → the protein acts as a signal, not just a catalyst.
- Authors frame it as "a regulatory paradigm employing **enzymes and pseudoenzymes that may have broad implications in biology**."

### FUNCTION — synthesis so far
The trypanosome AdoMetDC prozyme is a **dead enzyme repurposed as a dedicated allosteric activator**: it binds the active enzyme, flips it out of an auto-inhibited conformation (proline flip + β-sheet rearrangement + N-helix capture), and raises k_cat up to ~1,200×. Its own abundance is feedback-tuned by the pathway product (dcAdoMet) and by AdoMetDC protein. This replaces the spermidine feedback that higher eukaryotes use — i.e. the dead copy IS the parasite's polyamine-regulation strategy.

### STILL NEEDED
- DHS dead paralog (parallel case) — Nguyen 2013.
- PRMT prozyme — the already-published free-living-Bodo precedent.
- General pseudoenzyme "why conserved under selection" reviews.
- Paywalled reviews to ILL: Willert & Phillips 2012 Trends Parasitol; Kim & Barrett 2013 Mol Microbiol commentary.
