import sys

def parse(path):
    seqs={}; name=None
    for line in open(path):
        line=line.rstrip('\n')
        if line.startswith('>'):
            name=line[1:].strip(); seqs[name]=''
        elif name is not None:
            seqs[name]+=line.strip()
    return seqs

aln=parse('/root/audit/bodo/pcon_check.aln')
order=['Human','Tbrucei_ACTIVE','Tbrucei_DEAD','Bodo_ACTIVE','Bodo_DEAD','Pcon_0025430_ACTIVE','Pcon_0025440_DEAD']
short={'Human':'Hs','Tbrucei_ACTIVE':'Tb_ACT','Tbrucei_DEAD':'Tb_DEAD','Bodo_ACTIVE':'Bodo_ACT','Bodo_DEAD':'Bodo_DEAD','Pcon_0025430_ACTIVE':'Pcon_ACT','Pcon_0025440_DEAD':'Pcon_DEAD'}

def col_of(ref, resnum):
    """ungapped residue number (1-based) in ref -> alignment column index"""
    s=aln[ref]; c=0
    for i,ch in enumerate(s):
        if ch!='-':
            c+=1
            if c==resnum: return i
    return None

def ref_res(ref,resnum):
    s=aln[ref].replace('-',''); 
    return s[resnum-1] if 0<resnum<=len(s) else '?'

def show(ref, positions, title):
    print('\n### %s  (reference: %s)'%(title,short[ref]))
    hdr='  Tb#  ref  | '+' '.join('%-9s'%short[n] for n in order)
    print(hdr); print('  '+'-'*len(hdr))
    for resnum,label in positions:
        col=col_of(ref,resnum)
        rr=ref_res(ref,resnum)
        if col is None:
            print('  %4s  %-3s  | (out of range)'%(resnum,label)); continue
        cells=[]
        for n in order:
            cells.append('%-9s'%aln[n][col])
        print('  %4d  %s%-3s | %s'%(resnum, rr, '', ' '.join(cells))+'   <%s>'%label)

# ---- ACTIVE-enzyme positions (Volkov Tb numbering) ----
active_pos=[(8,'L-h1'),(10,'L-h1'),(11,'M-h1'),(13,'M-h1'),(19,'R-h1end'),(20,'F20'),
            (26,'R26'),(27,'S27'),(28,'F28'),(29,'E29'),(30,'G30'),(31,'P31*'),
            (100,'C100cat'),(137,'W137'),(146,'M146'),(154,'R154'),
            (164,'I164'),(168,'I168'),(169,'D169'),(172,'H172'),(176,'Y176'),(243,'Y243')]
show('Tbrucei_ACTIVE', active_pos, 'A. ACTIVE-enzyme activation architecture')

# ---- PROZYME positions (Volkov prozyme numbering) ----
proz_pos=[(42,"E42'put"),(126,"W126'put"),(148,"M148'*"),(152,"Y152'*"),(156,"K156'"),
          (163,"H163'"),(171,"D171'"),(195,"D195'put"),(282,"D282'put"),(305,"R305'b15"),(309,"H309'b15")]
show('Tbrucei_DEAD', proz_pos, 'B. PROZYME activator-interface (numbering = my Tb_DEAD seq; validate vs Volkov)')
