import csv,collections,re
X='/mnt/user-data/uploads/unlabeled_fp_search/AdoMetDC_project/8_extra_runs/'
N={}
for r in csv.DictReader(open('ncbi_taxonomy.tsv'),delimiter='\t'):
    lin=[x.split(':',1) for x in r['lineage'].split('|') if x]
    N[r['taxid']]=dict(name=r['name'],lin=lin,names=[n for _,n in lin]+[r['name']],ranks={k:v for k,v in lin})
MERGED={'983967':'130810','2664453':'2017544','1169540':'1169539','104098':'438'}
T={r['candidate']:r for r in csv.DictReader(open(X+'candidate_taxonomy.tsv'),delimiter='\t')}
def L(acc):
    t=T[acc]['taxid']; t=MERGED.get(t,t); return N.get(t)
def has(acc,name):
    n=L(acc); return n is not None and name in n['names']
def short(acc,k=6):
    n=L(acc); return '>'.join(x for _,x in n['lin'][2:2+k]) if n else '?'
eng={r['candidate']:r for r in csv.DictReader(open(X+'1_engine/engine_calls.tsv'),delimiter='\t')}
pkt={r['candidate']:r for r in csv.DictReader(open(X+'2_pocket/switch_calls.tsv'),delimiter='\t')}
lid={r['candidate']:r for r in csv.DictReader(open(X+'lid_calls.tsv'),delimiter='\t')}
ok617=[c for c,r in eng.items() if r['fold_ok']=='true']
o=lambda r,s: (r[s+'_obs'][:1] if r[s+'_obs'] not in ('','-') else '-')
print('== merged taxids:',[(c,T[c]['organism'],T[c]['group'],N[MERGED[T[c]['taxid']]]['name']) for c in T if T[c]['taxid'] in MERGED])

print('\n== (b) Trypanosomatidae / Kinetoplastea / Euglenida among all 1000 hits')
for c in T:
    for nm in ['Trypanosomatidae','Kinetoplastea','Euglenida']:
        if has(c,nm): print(' ',nm,c,T[c]['organism'],'fold_ok617=',eng.get(c,{}).get('fold_ok'),'verdict=',eng.get(c,{}).get('verdict')); break

print('\n== (c) diatoms (Bacillariophyta) + brown algae (Phaeophyceae) among 617 passers: residues at 13,111,178')
for nm in ['Bacillariophyta','Phaeophyceae']:
    rows=[c for c in ok617 if has(c,nm)]
    combo=collections.Counter((o(pkt[c],'Leu13'),o(pkt[c],'Phe111'),o(pkt[c],'Glu178')) for c in rows)
    print(' ',nm,len(rows),dict(combo))
print('  all stramenopiles with N178+G111+T13:',[(c,T[c]['organism'],short(c,4)) for c in ok617 if (o(pkt[c],'Leu13'),o(pkt[c],'Phe111'),o(pkt[c],'Glu178'))==('T','G','N')])
print('  Q/N at 178:',[(c,T[c]['organism'],o(pkt[c],'Glu178'),short(c,3)) for c in ok617 if o(pkt[c],'Glu178') in 'QN'])

print('\n== (d) "all three" set: Phe285 changed + Asp174 lost + plus charge')
feat=collections.defaultdict(set)
for r in csv.DictReader(open(X+'3_cooccur/features.tsv'),delimiter='\t'): feat[r['target']].add(r['feature'])
foc=set(open(X+'3_cooccur/focus_phe285_changed.txt').read().split()) if False else None
foc=set(open(X+'3_cooccur/focus_phe285_changed.txt').read().split())
three=[c for c in foc if 'Asp174_lost+plus_charge' in feat.get(c,set())]
print('  n all-three =',len(three), collections.Counter(T[c]['group'] for c in three))
alg=[c for c in three if T[c]['group']=='algae']
print('  algae in all-three by NCBI lineage:',collections.Counter(short(c,4) for c in alg))
print('  Chara?',[ (c,T[c]['organism']) for c in alg if 'Chara' in T[c]['organism']])
print('  Chlorella-related (Chlorellaceae/Chlorellales)?',[(c,T[c]['organism']) for c in alg if has(c,'Chlorellales') or has(c,'Chlorellaceae')])
print('  animals in all-three:',[(c,T[c]['organism'],short(c,9)) for c in three if T[c]['group']=='animals'])
print('  protists in all-three:',[(c,T[c]['organism'],short(c,3)) for c in three if T[c]['group']=='protists'])

print('\n== (e) bacteria among 617 passers by NCBI phylum / class / genus')
bac=[c for c in ok617 if T[c]['group']=='Bacteria']
print(len(bac), collections.Counter(L(c)['ranks'].get('phylum','?') for c in bac))
for ph in ['Bdellovibrionota','Pseudomonadota']:
    print(' ',ph,'classes:',collections.Counter(L(c)['ranks'].get('class','?') for c in bac if L(c)['ranks'].get('phylum')==ph),
          'genera:',collections.Counter(L(c)['ranks'].get('genus','?') for c in bac if L(c)['ranks'].get('phylum')==ph))
for c in ['M4UAE0','A0A4Y8A1I9','A0AA37WWK6','Q0HW77','A0A4Y6IBM5','A0A0C3LM77','A0A2E7US95','A0A370GRZ2','A0A8T4ENY0','A0A401FWD8','A0A2D6ETJ2','A0A2H0QP72']:
    print('  ',c,T[c]['organism'],'|',short(c,7))
print('  WOW sec5 yeasts:',[(c,T[c]['organism'],short(c,5)) for c in ['A0A099P0P7','A0A2U9QYU9']])
print('  Phytophthora/Nothophytophthora:',[(c,T[c]['organism'],short(c,4)) for c in ['A0A329SCT9','A0A662X2J7']])
print('  Bodo/Neobodo/Palpitomonas/lemur/zander:',[(c,T[c]['organism'],short(c,5)) for c in ['A0A0S4JRG8','A0A7S1R469','A0A7S3GBT7','A0A8C5W2A6','A0A8C9YNV1']])
print('  Chara/Blomia:',[(c,T[c]['organism'],short(c,5)) for c in ['A0A388KA10','A0A9Q0MA78']])
print('  diatom/brown examples:',[(c,T[c]['organism'],short(c,5)) for c in ['B7FPB8','D7FY29','A0A1E7FKD8']])

print('\n== (f) lid: Phe285 replacements by NCBI subgroup (617 passers)')
def sub(c):
    n=L(c); nm=set(n['names'])
    for k in ['Polypodiopsida','Magnoliopsida','Embryophyta','Chlorophyta','Streptophyta','Bacillariophyta','Phaeophyceae','Oomycota','Stramenopiles','Haptophyta','Rhodophyta','Cryptophyceae','Cestoda','Platyhelminthes','Saccharomycotina','Fungi','Metazoa','Bacteria','Archaea']:
        if k in nm: return k
    return 'other:'+'>'.join(x for _,x in n['lin'][1:3])
rep=collections.defaultdict(collections.Counter); gen=collections.defaultdict(collections.Counter)
for c in ok617:
    r=lid[c]
    if r['Phe285_state'] in ('altered','lost'):
        a=r['Phe285_obs'][0]; rep[a][sub(c)]+=1; gen[a][L(c)['ranks'].get('genus','?')]+=1
for a in ['H','T','S','M','I','L','V','C']:
    print(' ',a,sum(rep[a].values()),dict(rep[a].most_common(8)))
for a,gs in [('H',['Arabidopsis','Brassica','Citrus','Actinidia','Adiantum','Ceratopteris']),('T',['Musa','Rhododendron','Carpinus']),('I',['Mesocestoides','Hymenolepis'])]:
    print('  check genera',a,{g:gen[a].get(g,0) for g in gs})
for g in ['Adiantum','Ceratopteris']:
    cs=[c for c in ok617 if L(c)['ranks'].get('genus')==g]; print('  ',g,[(c,short(c,6)) for c in cs][:2])
print('  T at 285 haptophytes:',[(c,T[c]['organism']) for c in ok617 if lid[c]['Phe285_state'] in('altered','lost') and lid[c]['Phe285_obs'][0]=='T' and has(c,'Haptophyta')])
print('  I at 285 Saccharomycotina:',[(c,T[c]['organism']) for c in ok617 if lid[c]['Phe285_state'] in('altered','lost') and lid[c]['Phe285_obs'][0]=='I' and has(c,'Saccharomycotina')])
