| Clade | Class | Organism | UniProt | L13 | F111 | D174 | **E178** | E256 | F285 |
|---|---|---|---|---|---|---|---|---|---|
| Ochrophyta | Bacillariophyceae | *Cylindrotheca closterium* | A0AAD2GAL3 | T | G | D | **N** | E | M |
| Ochrophyta | Bacillariophyceae | *Fragilariopsis cylindrus CCMP1102* | A0A1E7FKD8 | T | G | D | **N** | E | M |
| Ochrophyta | Bacillariophyceae | *Nitzschia inconspicua* | A0A9K3LMG5 | T | G | D | **N** | E | M |
| Ochrophyta | Bacillariophyceae | *Phaeodactylum tricornutum CCAP 1055/1* | B7FPB8 | T | G | D | **N** | E | M |
| Ochrophyta | Bolidophyceae | *Triparma laevis f. inornata* | A0A9W7AQ06 | - | G | D | **N** | E | M |
| Ochrophyta | Bolidophyceae | *Triparma strigata* | A0A9W7EFJ6 | T | G | D | **N** | E | M |
| Ochrophyta | Chrysophyceae | *Spumella elongata* | A0A7S3H9T9 | - | G | Y | **N** | E | F |
| Ochrophyta | Coscinodiscophyceae | *Chaetoceros tenuissimus* | A0AAD3D8K8 | T | G | D | **N** | E | M |
| Ochrophyta | Coscinodiscophyceae | *Cyclotella cryptica* | A0ABD3QT96 | T | G | D | **N** | E | M |
| Ochrophyta | Coscinodiscophyceae | *Proboscia inermis* | A0A7S0C0C1 | L | G | D | **N** | E | M |
| Ochrophyta | Dictyochophyceae | *Octactis speculum* | A0A7S2HLL7 | N | G | T | **N** | E | M |
| Ochrophyta | Dictyochophyceae | *Octactis speculum* | A0A7S2HLM3 | N | G | T | **N** | E | M |
| Ochrophyta | Eustigmatophyceae | *Nannochloropsis salina CCMP1776* | A0A4D9CSB4 | T | G | D | **N** | E | M |
| Ochrophyta | Fragilariophyceae | *Cyclophora tenuis* | A0A7S1CXK8 | - | G | D | **D** | E | M |
| Ochrophyta | Pelagophyceae | *Aureococcus anophagefferens* | F0Y0A9 | T | G | E | **N** | E | F |
| Ochrophyta | Pelagophyceae | *Chrysophaeum taylorii* | A0AAD7XHA9 | T | G | E | **N** | E | F |
| Ochrophyta | Phaeophyceae | *Ectocarpus siliculosus* | D7FY29 | T | G | D | **N** | E | F |
| Ochrophyta | Phaeophyceae | *Ectocarpus sp. CCAP 1310/34* | A0A6H5KT37 | T | G | D | **N** | E | F |
| Ochrophyta | Phaeophyceae | *Ectocarpus sp. CCAP 1310/34* | A0A6H5KVY3 | T | G | D | **N** | E | V |
| Ochrophyta | Pinguiophyceae | *Phaeomonas parva* | A0A7S1XYU7 | T | G | D | **N** | E | F |
| Ochrophyta | Xanthophyceae | *Tribonema minus* | A0A835ZL65 | T | G | D | **N** | E | M |
| Bigyra | Bigyra | *Blastocystis hominis* | D8LUU6 | I | L | S | **N** | E | T |
| Bigyra | Bigyra | *Blastocystis sp. ATCC 50177/Nand II* | A0A196S442 | I | L | G | **N** | E | C |
| Bigyra | Bigyra | *Cafeteria roenbergensis* | A0A5A8CY83 | T | C | D | **N** | E | F |
| Bigyra | Bigyra | *Hondaea fermentalgiana* | A0A2R5GFL0 | I | G | E | **N** | E | F |
| Oomycota | Oomycota | *Aphanomyces invadans* | A0A024TG05 | N | R | E | **H** | E | S |
| Oomycota | Oomycota | *Hyaloperonospora arabidopsidis Emoy2* | M4BIM5 | N | N | E | **H** | E | Y |
| Oomycota | Oomycota | *Lagenidium giganteum* | A0AAV2Z8E4 | N | S | E | **H** | E | Y |
| Oomycota | Oomycota | *Nothophytophthora sp. Chile5* | A0A662X2J7 | - | S | E | **Q** | E | Y |
| Oomycota | Oomycota | *Phytophthora cactorum* | A0A329SCT9 | - | N | E | **Q** | E | Y |
| Oomycota | Oomycota | *Saprolegnia diclina VS20* | T0REK4 | N | R | E | **H** | E | S |
