import json,csv
from collections import Counter
rows=json.load(open('all_rows.json'))
D='/mnt/user-data/uploads/unlabeled_fp_search/AdoMetDC_project/8_extra_runs/'
# pull E15 too
extra={}
for r in csv.DictReader(open(D+'2_pocket/switch_calls.tsv'),delimiter='\t'):
    g=lambda k: r[k+'_obs'][0] if r[k+'_obs'] not in ('-','') else '-'
    extra[r['candidate']]=dict(E15=g('Glu15'),S113=g('Ser113'),K80=g('Lys80'))
ochro_cls={'Bacillariophyceae','Coscinodiscophyceae','Fragilariophyceae','Eustigmatophyceae','Phaeophyceae',
           'Chrysophyceae','Xanthophyceae','Bolidophyceae','Pelagophyceae','Pinguiophyceae','Dictyochophyceae'}
def clade(x):
    if x['phylum']=='Bacillariophyta' or x['cls'] in ochro_cls: return 'Ochrophyta'
    if x['cls']=='Bigyra': return 'Bigyra'
    if x['phylum']=='Oomycota': return 'Oomycota'
    return None
fp=[x for x in rows if x['fold']=='true']
S=[x for x in fp if clade(x)]
print('Stramenopile fold-passers:',len(S), Counter(clade(x) for x in S))
print('\nPer stramenopile clade, residue at each pocket position (human numbering):')
for c in ['Ochrophyta','Bigyra','Oomycota']:
    sub=[x for x in S if clade(x)==c]
    print(' ',c,'n=',len(sub))
    for pos in ['L13','F111','D174','T176','E178','E256','F285']:
        print('     %-5s'%pos, dict(Counter(x[pos] for x in sub)))
    print('     E15  ', dict(Counter(extra[x['acc']]['E15'] for x in sub)))
# Ochrophyta classes covered
print('\nOchrophyta classes/phyla covered:', sorted(set((x['cls'] or x['phylum']) for x in S if clade(x)=='Ochrophyta')))
# contingency: E178 retained (E) vs replaced, eukaryotes
euk=[x for x in fp if x['group'] in ('animals','fungi','plants','algae','protists')]
def isS(x): return clade(x) is not None
a=sum(1 for x in euk if isS(x) and x['E178']=='E'); b=sum(1 for x in euk if isS(x) and x['E178'] not in ('E','-'))
c=sum(1 for x in euk if not isS(x) and x['E178']=='E'); d=sum(1 for x in euk if not isS(x) and x['E178'] not in ('E','-'))
print('\nEukaryote fold-passers, Glu178:  stramenopiles retained=%d replaced=%d | all other eukaryotes retained=%d replaced=%d'%(a,b,c,d))
others=[x for x in euk if not isS(x) and x['E178'] not in ('E','-')]
print('Non-stramenopile eukaryotes with Glu178 replaced:')
for x in others: print('   %-12s %-34.34s %-9s %-18s E178=%s L13=%s F111=%s len=%s'%(x['acc'],x['org'],x['group'],(x['cls'] or x['phylum']),x['E178'],x['L13'],x['F111'],x['length']))
