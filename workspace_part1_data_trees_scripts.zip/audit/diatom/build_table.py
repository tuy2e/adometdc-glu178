import csv
D='/mnt/user-data/uploads/unlabeled_fp_search/AdoMetDC_project/8_extra_runs/'
tax={}
for r in csv.DictReader(open(D+'candidate_taxonomy.tsv'),delimiter='\t'):
    tax[r['candidate']]=r
rows=[]
for r in csv.DictReader(open(D+'2_pocket/switch_calls.tsv'),delimiter='\t'):
    t=tax.get(r['candidate'],{})
    aa=lambda k: r[k+'_obs'][0] if r[k+'_obs'] not in ('-','') else '-'
    rows.append(dict(acc=r['candidate'],fold=r['fold_ok'],tm=r['tm_norm_ref'],
        L13=aa('Leu13'),F111=aa('Phe111'),D174=aa('Asp174'),T176=aa('Thr176'),E178=aa('Glu178'),E256=aa('Glu256'),F285=aa('Phe285'),
        org=t.get('organism',''),taxid=t.get('taxid',''),group=t.get('group',''),phylum=t.get('phylum',''),cls=t.get('class',''),genus=t.get('genus',''),length=t.get('length','')))
import json; json.dump(rows,open('all_rows.json','w'))
fp=[x for x in rows if x['fold']=='true']
print('total rows',len(rows),' fold-pass',len(fp))
from collections import Counter
print('fold-pass by group:',Counter(x['group'] for x in fp))
# E178 state by group among fold-passers
print('\nGlu178 residue by group (fold-pass):')
for g in sorted(set(x['group'] for x in fp)):
    c=Counter(x['E178'] for x in fp if x['group']==g)
    print('  %-9s'%g, dict(c))
# write algae+protists table
with open('algae_protists_pocket.tsv','w') as f:
    f.write('acc\tfold\torganism\ttaxid\tgroup\tphylum\tclass\tgenus\tlen\tL13\tF111\tD174\tT176\tE178\tE256\tF285\n')
    for x in rows:
        if x['group'] in ('algae','protists'):
            f.write('\t'.join([x['acc'],x['fold'],x['org'],x['taxid'],x['group'],x['phylum'],x['cls'],x['genus'],x['length'],x['L13'],x['F111'],x['D174'],x['T176'],x['E178'],x['E256'],x['F285']])+'\n')
print('\nwrote algae_protists_pocket.tsv')
