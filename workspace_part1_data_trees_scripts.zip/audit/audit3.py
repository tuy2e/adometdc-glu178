exec(open('audit2.py').read().split("print('== Glu247 Gln")[0])
q=[a for a in ok643 if calls[a]['Glu247_obs'][:1]=='Q' and T[a]['group']=='protists']
print('protist Gln:',[(a,T[a]['organism'],'>'.join(x for _,x in L(a)['lin'][1:5])) for a in q])
print('Ochrophyta counted as protists (all 1000):',[(c,T[c]['organism'],'>'.join(x for _,x in L(c)['lin'][3:7]),c in ok643,c in ok617) for c in T if T[c]['group']=='protists' and has(c,'Ochrophyta')])
print('photosynthetic-lineage protists (Chlorarachniophyceae/Euglenida/Ochrophyta) in 643:',sum(1 for c in ok643 if T[c]['group']=='protists' and (has(c,'Ochrophyta') or has(c,'Chlorarachniophyceae') or has(c,'Euglenida'))))
# Phe285 by group (617)
c=collections.defaultdict(collections.Counter)
for a in ok617: c[T[a]['group']][lid[a]['Phe285_state']]+=1
for g,v in c.items():
    res=v['retained']+v['altered']+v['lost']; print('Phe285',g,dict(v),'kept %.0f%% of resolved'%(100*v['retained']/res) if res else '')
# Glu247 lost per group 643
cc=collections.defaultdict(collections.Counter)
for a in ok643: cc[T[a]['group']][calls[a]['Glu247_state']]+=1
print({g:dict(v) for g,v in cc.items()})
