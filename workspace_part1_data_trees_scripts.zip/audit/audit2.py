exec(open('audit.py').read().split("print('== merged taxids")[0])
import csv,collections
from Bio import Phylo
calls={r['candidate_id'].split('-')[1]:r for r in csv.DictReader(open('/mnt/user-data/uploads/unlabeled_fp_search/unlabeled-fp-search/aim1_workflow/runs/stuy__adometdc_1I7B/foldtrace_calls.tsv'),delimiter='\t')}
ok643=[a for a,r in calls.items() if r['fold_ok']=='true']
def cls(c):
    n=L(c); r=n['ranks']; return f"{r.get('phylum','-')}/{r.get('class','-')}"
print('== Glu247 Gln (643 set) by NCBI phylum/class, per group')
q=[a for a in ok643 if calls[a]['Glu247_obs'][:1]=='Q']
for g in ['animals','protists','plants','fungi','algae','Bacteria']:
    print(' ',g,sum(1 for a in q if T[a]['group']==g),collections.Counter(cls(a) for a in q if T[a]['group']==g).most_common())
print('\n== bacteria in 643 set with no phylum:',[(a,T[a]['organism'],'>'.join(x for _,x in L(a)['lin'])) for a in ok643 if T[a]['group']=='Bacteria' and 'phylum' not in L(a)['ranks']])
print('== 617-set bacteria no phylum / Pseudomonadota no class:',[(c,T[c]['organism'],'>'.join(x for _,x in L(c)['lin'])) for c in ok617 if T[c]['group']=='Bacteria' and ('phylum' not in L(c)['ranks'] or (L(c)['ranks'].get('phylum')=='Pseudomonadota' and 'class' not in L(c)['ranks']))])
nb={r['acc']:r for r in csv.DictReader(open('/root/fam/out/neighborhood_per_protein.tsv'),delimiter='\t')}
spe=[a for a,r in nb.items() if r['spermidine synthase (speE)']]
spa=[a for a,r in nb.items() if r['arginine decarboxylase (speA)']]
none=[a for a,r in nb.items() if r['group'] in('Bacteria',) and not (r['spermidine synthase (speE)'] or r['arginine decarboxylase (speA)'] or r['agmatinase (speB)'])]
print('\n== speE bacteria by NCBI phylum:',len(spe),collections.Counter(L(a)['ranks'].get('phylum','(none)') for a in spe))
print('== speA bacteria class/genus:',[(a,L(a)['ranks'].get('class'),L(a)['ranks'].get('genus'),bool(nb[a]['agmatinase (speB)'])) for a in spa])
print('== no-polyamine bacteria:',len(none))
for a in none: print('   ',a,T[a]['organism'][:35],'|',L(a)['ranks'].get('phylum','(none)'),'|',L(a)['ranks'].get('class','-'),'|',L(a)['ranks'].get('order','-'),'|',L(a)['ranks'].get('genus','-'))
t=Phylo.read('/root/fam/out/adometdc_family_tree.nwk','newick')
ca=t.common_ancestor('A0A370GRZ2','A0A8T4ENY0')
p=t.get_path(next(t.find_clades('A0A370GRZ2')))
for anc in reversed(p[:-1]):
    if anc.count_terminals()>=4:
        print('\n== Aquicella clade:',[(l.name,T[l.name]['organism'],L(l.name)['ranks'].get('class','-'),L(l.name)['ranks'].get('phylum','-')) for l in anc.get_terminals()]); break
