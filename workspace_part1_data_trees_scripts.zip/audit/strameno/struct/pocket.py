import warnings; warnings.filterwarnings('ignore')
from Bio.PDB import PDBParser, Superimposer
import numpy as np, json, subprocess
U='/mnt/user-data/uploads/unlabeled_fp_search/unlabeled-fp-search/aim1_workflow/runs/stuy__adometdc/'
p=PDBParser(QUIET=True)
H=p.get_structure('h',U+'1MSV.pdb')[0]['A']
put=[r for r in H if r.get_resname()=='PUT'][0]
putxyz=np.array([a.coord for a in put])
putN=[a for a in put if a.element=='N']
hseq_res=[r for r in H if r.id[0]==' ']
three={'ALA':'A','ARG':'R','ASN':'N','ASP':'D','CYS':'C','GLN':'Q','GLU':'E','GLY':'G','HIS':'H','ILE':'I','LEU':'L','LYS':'K','MET':'M','PHE':'F','PRO':'P','SER':'S','THR':'T','TRP':'W','TYR':'Y','VAL':'V'}
M=json.load(open('master.json')); HS=M['P17707']['seq']
def residues(model_file):
    s=p.get_structure('t',model_file)[0]; ch=list(s)[0]
    return [r for r in ch if r.id[0]==' ']
def align_map(tseq):
    open('struct/tmp.fa','w').write('>H\n%s\n>T\n%s\n'%(HS,tseq))
    out=subprocess.run(['mafft','--quiet','--localpair','--maxiterate','1000','struct/tmp.fa'],capture_output=True,text=True).stdout
    a={};n=None
    for l in out.splitlines():
        if l.startswith('>'): n=l[1:]; a[n]=''
        else: a[n]+=l.strip()
    m={};hc=tc=0
    for x,y in zip(a['H'],a['T']):
        if x!='-': hc+=1
        if y!='-': tc+=1
        if x!='-' and y!='-': m[hc]=tc
    return m
def analyse(acc,label):
    tres=residues(U+'models/%s.pdb'%acc)
    tseq=''.join(three.get(r.get_resname(),'X') for r in tres)
    m=align_map(tseq)
    hby={r.id[1]:r for r in hseq_res}; tby={i+1:r for i,r in enumerate(tres)}
    # local superposition: human residues with CA within 18 A of putrescine
    near=[n for n,r in hby.items() if 'CA' in r and np.min(np.linalg.norm(putxyz-r['CA'].coord,axis=1))<18 and n in m and m[n] in tby]
    fixed=[hby[n]['CA'] for n in near]; moving=[tby[m[n]]['CA'] for n in near]
    sup=Superimposer(); sup.set_atoms(fixed,moving)
    rot,tran=sup.rotran
    def T(x): return np.dot(x,rot)+tran
    out={'acc':acc,'label':label,'n_ca':len(near),'rmsd':round(float(sup.rms),2)}
    # pocket residues
    rows=[]
    for hp,name in [(13,'L13'),(15,'E15'),(111,'F111'),(174,'D174'),(176,'T176'),(178,'E178'),(256,'E256'),(285,'F285')]:
        hr=hby.get(hp); tp=m.get(hp); tr=tby.get(tp) if tp else None
        hd=min(np.linalg.norm(a.coord-b.coord) for a in hr for b in putN) if hr else None
        td=None;plddt=None
        if tr is not None:
            td=min(np.linalg.norm(T(a.coord)-b.coord) for a in tr for b in putN)
            plddt=round(float(np.mean([a.bfactor for a in tr])),1)
        rows.append(dict(site=name,human=hr.get_resname() if hr else '-',human_minN=round(float(hd),2) if hd else None,
                         target=(tr.get_resname()+str(tp)) if tr is not None else '-',target_minN=round(float(td),2) if td is not None else None,plddt=plddt))
    out['rows']=rows
    # anything of the target sitting where putrescine would be?
    clash=[]
    for r in tres:
        for a in r:
            d=float(np.min(np.linalg.norm(putxyz-T(a.coord),axis=1)))
            if d<2.8: clash.append((r.get_resname()+str(r.id[1]),a.get_id(),round(d,2)))
    out['atoms_within_2.8A_of_putrescine']=clash
    return out
res=[]
for acc,label in [('B7FPB8','diatom Phaeodactylum'),('D7FY29','brown alga Ectocarpus'),('A0A5A8CY83','bicosoecid Cafeteria'),('M4BIM5','oomycete Hyaloperonospora')]:
    r=analyse(acc,label); res.append(r)
    print('\n== %s (%s): superposed on %d pocket-region CA, RMSD %.2f A'%(label,acc,r['n_ca'],r['rmsd']))
    print('   site   human(min dist to putrescine N)   target(min dist after superposition)  target pLDDT')
    for x in r['rows']:
        print('   %-5s  %-4s %5s A                       %-7s %5s A                       %s'%(x['site'],x['human'],x['human_minN'],x['target'],x['target_minN'],x['plddt']))
    print('   target atoms occupying the putrescine site (<2.8 A):',r['atoms_within_2.8A_of_putrescine'])
json.dump(res,open('struct/pocket_results.json','w'))
