import warnings; warnings.filterwarnings('ignore')
import numpy as np, json
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from Bio.PDB import PDBParser
src=open('struct/pocket.py').read().split("res=[]")[0]; exec(src)
fits={r['acc']:r for r in json.load(open('struct/pocket_core_fit.json'))}
sites=[(13,'L13'),(15,'E15'),(111,'F111'),(174,'D174'),(176,'T176'),(178,'E178'),(256,'E256'),(285,'F285')]
col={'ASP':'#c0392b','GLU':'#c0392b','ASN':'#16a085','GLN':'#16a085','HIS':'#2e86de','ARG':'#2e86de','LYS':'#2e86de',
     'THR':'#7d8a99','SER':'#7d8a99','GLY':'#7d8a99','LEU':'#555','PHE':'#555','MET':'#555','VAL':'#555','TYR':'#555','CYS':'#555','ILE':'#555','ALA':'#555'}
hby={r.id[1]:r for r in hseq_res}
def human_pocket():
    return [(name,hby[hp],None) for hp,name in sites]
def target_pocket(acc):
    tres=residues(U+'models/%s.pdb'%acc); tseq=''.join(three.get(r.get_resname(),'X') for r in tres)
    m=align_map(tseq); tby={i+1:r for i,r in enumerate(tres)}
    rot=np.array(fits[acc]['rot']); tran=np.array(fits[acc]['tran'])
    return [(name,tby.get(m.get(hp)),(rot,tran)) for hp,name in sites]
# common view from PCA of human pocket + putrescine
allxyz=np.vstack([putxyz]+[np.array([a.coord for a in r]) for _,r,_ in human_pocket()])
cen=allxyz.mean(0)
cents=[putxyz.mean(0)]+[np.array([a.coord for a in r if a.get_id() not in ('N','C','O')]).mean(0) for _,r,_ in human_pocket()]
rng=np.random.default_rng(7); best=(-1,None)
for _ in range(6000):
    q,_r=np.linalg.qr(rng.normal(size=(3,3))); Vt=q.T[:2]
    P2=np.dot(np.array(cents)-cen,Vt.T)
    d=min(np.linalg.norm(P2[i]-P2[j]) for i in range(len(P2)) for j in range(i+1,len(P2)))
    if d>best[0]: best=(d,Vt)
V=best[1]
def proj(x): return np.dot(x-cen,V.T)
def draw(ax,pocket,title,put_style):
    # putrescine
    P=proj(putxyz)
    ax.plot(P[:,0],P[:,1],'-',color='#e1a100' if put_style=='solid' else '#e1a100',lw=4 if put_style=='solid' else 3,
            alpha=1 if put_style=='solid' else 0.45,zorder=5,solid_capstyle='round')
    for a in put:
        if a.element=='N':
            q=proj(a.coord); ax.scatter(q[0],q[1],s=70,color='#2e86de',edgecolor='k',zorder=6,alpha=1 if put_style=='solid' else 0.5)
    ax.text(P[:,0].mean(),P[:,1].mean()-1.3,'putrescine' if put_style=='solid' else 'putrescine\n(position in human)',
            ha='center',va='top',fontsize=8,color='#9a6b00')
    for name,res,tf in pocket:
        if res is None: continue
        atoms=[a for a in res if a.element!='H' and a.get_id() not in ('N','C','O')]
        X=np.array([a.coord for a in atoms])
        if tf is not None: X=np.dot(X,tf[0])+tf[1]
        Q=proj(X); c=col.get(res.get_resname(),'#555')
        # bonds
        for i in range(len(atoms)):
            for j in range(i+1,len(atoms)):
                if np.linalg.norm(X[i]-X[j])<1.9: ax.plot([Q[i,0],Q[j,0]],[Q[i,1],Q[j,1]],'-',color=c,lw=4 if name=='E178' else 2.4,zorder=3)
        if res.get_resname()=='GLY':
            ax.scatter(Q[0,0],Q[0,1],s=90,color='#7d8a99',edgecolor='k',zorder=4)
        # polar atoms
        for k,a in enumerate(atoms):
            if a.element in ('O','N') and a.get_id() not in ('N','O'):
                ax.scatter(Q[k,0],Q[k,1],s=28,color='#c0392b' if a.element=='O' else '#2e86de',zorder=4)
        lab=res.get_resname().capitalize()+str(res.id[1]) if tf is not None else res.get_resname().capitalize()+str(res.id[1])
        tip=Q[np.argmax(np.linalg.norm(Q-proj(putxyz).mean(0),axis=1))] if False else Q[-1]
        hl = name=='E178'
        pc=proj(putxyz).mean(0); cc=Q.mean(0); dv=cc-pc; dv=dv/(np.linalg.norm(dv)+1e-6)
        lp=cc+dv*1.6
        ax.text(lp[0],lp[1],lab,ha='center',va='center',fontsize=9 if hl else 8,fontweight='bold' if hl else 'normal',
                color='black',zorder=7,bbox=dict(boxstyle='round,pad=0.15',fc='#fff3b0' if hl else 'white',ec='#c9a400' if hl else 'none',alpha=0.9))
    ax.set_title(title,fontsize=10.5)
    ax.set_aspect('equal'); ax.axis('off')
fig,axes=plt.subplots(1,3,figsize=(15,5.6))
draw(axes[0],human_pocket(),'A  Human AdoMetDC (crystal structure 1MSV)\nputrescine bound; Glu178 present','solid')
draw(axes[1],target_pocket('B7FPB8'),'B  Diatom Phaeodactylum (AlphaFold, superposed)\nAsn at the Glu178 position; Gly at Phe111','ghost')
draw(axes[2],target_pocket('M4BIM5'),'C  Oomycete Hyaloperonospora (AlphaFold, superposed)\nHis at the Glu178 position','ghost')
# shared limits
xs=[];ys=[]
for ax in axes: x0,x1=ax.get_xlim(); y0,y1=ax.get_ylim(); xs+= [x0,x1]; ys+=[y0,y1]
for ax in axes: ax.set_xlim(min(xs),max(xs)); ax.set_ylim(min(ys),max(ys))
fig.text(0.5,0.02,'Labels give each protein\'s own residue numbers; residues shown are the structural equivalents of human L13, E15, F111, D174, T176, E178, E256, F285. '
         'Red = acidic, green = amide (Asn/Gln), blue = basic/His, grey = other. Core superposition RMSD: diatom 0.95 Å, oomycete 0.78 Å.',ha='center',fontsize=8,wrap=True)
plt.tight_layout(rect=[0,0.05,1,1])
plt.savefig('/mnt/user-data/outputs/Fig_pocket_human_vs_stramenopile.png',dpi=200)
print('saved')
