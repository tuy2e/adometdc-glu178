## Step 5 — Check the prediction against enzymes whose putrescine response has been measured ✅
I looked up every AdoMetDC whose putrescine response has been measured, pulled its sequence from UniProt, and mapped it with the same pipeline. Abstracts and full text were checked on PubMed/PMC.

**First, the mapping reproduces published residue numbers:**
- *C. elegans*: T192, E194, E274 match Ndjonka 2003 exactly.
- Potato: R18, R114, V181, H294 match Bennett 2002 exactly.
- *T. cruzi*: 9 of 10 residues named in Clyne 2002 / Beswick 2006 match (F7, R13, E15, I80, D174, S178, T245, E256, F285). The one miss is Ser111, where our alignment is 2 residues off because of a nearby gap. I note this for the F111 calls in trypanosomes; the stramenopile F111 calls are backed by FOLDTRACE.
- The *Acanthamoeba castellanii* peptide that Hugo & Byers sequenced (UniProt P34039) matches the N-terminus of L8GRS6 exactly. So L8GRS6 is the protein they purified.

| Organism (UniProt) | Measured putrescine response | Source (PMID) | Residue at 178 | Fits the rule? |
|---|---|---|---|---|
| Human (P17707) | Activated (processing + activity). **E178Q: ~4× WT activity without putrescine, no further stimulation** | Stanley 1994 (8132508); Bale 2008 Table 4 (19053272) | **E** | ✅ |
| Yeast *S. cerevisiae* (P21182) | "putrescine-activated" | Pegg & Jacobs 1983 (6351843); Karvonen 1985 (3933487) | **E**213 | ✅ |
| *Neurospora crassa* (Q9Y7F3) | Putrescine **absolutely required** for activity | Hoyt 2000 (10852489) | **E**258 | ✅ |
| *C. elegans* (O02655) | **350-fold** stimulated. **E194Q (= human E178Q): 100-fold higher activity with no activator** | Ndjonka 2003 (12674502) | **E**194 | ✅ key precedent |
| *Onchocerca volvulus* (Q27883) | 15-fold stimulated | Da'dara 1998 (9879883) | **E**196 | ✅ |
| *Acanthamoeba castellanii* (L8GRS6) | 2-fold stimulated (weak) | Hugo & Byers 1993 (8216217) | **E**202 | ✅ |
| *Acanthamoeba culbertsoni* | Strongly activated | Gupta 1987 (3600699) | no sequence available | – |
| Potato (Q04694), *Arabidopsis* (Q96286) | **Not** stimulated; fully active alone | Bennett 2002 (12463749) | **E**185 / **E**182 | ✅ different route: Glu kept, but Arg/Lys/His built into the pocket mimic putrescine |
| *P. falciparum* (Q9Y1L5) | AdoMetDC domain **not** stimulated | Wrenger 2001 (11390378) | **S** | ✅ |
| ***T. cruzi* (O76240)** | **Stimulated 11–27-fold**; binding needs **Asp174 only**; mutating Ser178 has no effect | Clyne 2002 (12403622); Beswick 2006 (16784231) | **S**194 | ❌ **exception** |
| *Tetrahymena* | **Not** stimulated | Pösö 1975 (813467) | n/a: no class-2 (PF01536) enzyme in UniProt for *Tetrahymena*. Its only AdoMetDCs are 6 small prokaryotic-type (PF02675) domains fused to spermidine synthase | ✅ explained by enzyme class, not residue 178 |

**What this means for the prediction (stated carefully):**
- **Glu178 marks the activated enzymes.** All 6 measured, putrescine-activated enzymes outside trypanosomes keep it.
- **Removing Glu178 has a known effect in two species.** In the human enzyme, E178Q gives ~4× wild-type activity with no putrescine, and putrescine adds nothing. In the worm enzyme, the equivalent E194Q gives 100× higher activity with no activator. Stramenopiles carry the natural version of this change. Ochrophyta and Bigyra have Asn, a close relative of Gln.
- **But *T. cruzi* shows another possible outcome.** It lacks Glu178 and is still putrescine-activated, because Asp174 alone binds putrescine. Stramenopiles keep Asp174 (Glu in oomycetes) and Glu256. So some putrescine binding could remain.
- **The honest prediction:** stramenopile AdoMetDC should have **high activity without putrescine and little or no extra stimulation**, like E178Q. A *T. cruzi*-like residual response cannot be ruled out from sequence alone. The experiment (activity ± putrescine) decides between them.
- **Correction to step 1:** I had listed *Tetrahymena* (Pösö 1975) as a possible validation point. It isn't one. *Tetrahymena* has no class-2 enzyme at all, so its insensitivity tells us nothing about residue 178.

## Step 6 — Structure figure: human vs diatom pocket ✅
- **Method:** human crystal structure 1MSV (putrescine bound, chain A) vs the AlphaFold models already in your FOLDTRACE run. I superposed each pair on the residues near the pocket, refining the fit iteratively. Core RMSD: diatom *Phaeodactylum* 0.95 Å, brown alga *Ectocarpus* 0.76 Å, *Cafeteria* 0.83 Å, oomycete *Hyaloperonospora* 0.78 Å. pLDDT at the pocket residues is 80–98, so the models are confident there.
- **Figure:** `Fig_pocket_human_vs_stramenopile.png`. A = human, B = diatom, C = oomycete.

**Closest approach of each pocket residue to putrescine's nitrogens (Å). AlphaFold confidence (pLDDT) in brackets:**

| Human residue (1MSV) | Human | Diatom *Phaeodactylum* | Brown alga *Ectocarpus* | *Cafeteria* (Bigyra) | Oomycete *Hyaloperonospora* |
|---|---|---|---|---|---|
| L13 | 3.4 | Thr12 3.6 (97) | Thr56 3.9 (98) | Thr32 4.1 (98) | Asn29 3.1 (98) |
| E15 | 2.8 | Glu14 3.2 (96) | Glu58 2.6 (97) | Glu34 2.6 (97) | Glu31 2.7 (98) |
| F111 | 4.5 | **Gly124** 5.8 (95) | **Gly148** 5.7 (95) | Cys124 4.5 (96) | Asn121 3.2 (96) |
| D174 | 2.9 | Asp194 3.7 (80) | Asp210 4.1 (83) | Asp187 4.2 (87) | Glu199 3.6 (78) |
| T176 | 2.7 | Val196 3.2 (93) | Thr212 3.1 (95) | Thr189 3.0 (94) | Thr201 3.0 (92) |
| **E178** | 5.2 | **Asn198** 7.2 (95) | **Asn214** 6.8 (98) | **Asn191** 5.0 (98) | **His203** 3.7 (96) |
| E256 | 5.0 | Glu289 5.6 (97) | Glu292 5.3 (98) | Glu352 4.6 (98) | Glu282 4.8 (98) |
| F285 | 4.5 | Met318 3.0 (88) | Phe321 4.7 (93) | Phe381 4.6 (92) | Tyr311 4.3 (88) |

**Reading it:**
- **Ochrophyta and Bigyra (diatom, brown alga, *Cafeteria*):** the pocket is still there and still lined with acid (Glu15, Asp174, Glu256). The Glu178 spot holds a **neutral Asn**. No side chain fills the space where putrescine sits. In human 1MSV, Glu178 contacts putrescine through a bridging water (Bale 2008), which fits its 5.2 Å distance. Bale also reports that E178Q *lacks* that bridging water, which is why putrescine no longer activates it. The diatom geometry looks like that mutant, not like the plant solution. **Gly** at F111 (Ochrophyta) removes one of the two aromatic walls. *New:* a **Trp** at the human Ser109 position (Trp122 in *Phaeodactylum*, Trp146 in *Ectocarpus*, Trp122 in *Cafeteria*) reaches to within 3–4 Å of the putrescine site, close to where human Phe111's ring sits (3.7 Å). So the aromatic wall seems to have **moved over by two residues** rather than disappeared. This Trp is shared across the whole Glu-less lineage (step 4).
- **Oomycete:** the pocket is **partly filled by the protein's own side chains**. His203 sits at the Glu178 spot and points in (3.7 Å). Asn121 replaces Phe111, and a Tyr (Tyr354, outside the 8 mapped positions) has its OH 2.1 Å from where putrescine's nitrogen sits in human. That's closer to the plant idea (a built-in side chain occupying the activator site), so **oomycetes may differ from diatoms**. This is a possible sub-finding.
- **Limits:** AlphaFold models have no ligand and no water. This shows pocket *shape and chemistry*, not binding.

