# Stramenopile AdoMetDCs lost the putrescine sensor (Glu178): results, steps 2–6 + wider sampling
*Tui, 5 Nov 2026 (updated the same evening). This is my computational analysis, not Marc's protocol. I used your FOLDTRACE run read-only and changed nothing in your project folder. No wet lab. Step 1 is in `stramenopile_Glu178_step1_results.md`.*

> **What's new in this update**
> 1. **Michael 2011 is read in full, and our novelty holds** (details below).
> 2. **Sampling is about 3× wider:** 339 active enzymes, now including cryptophytes, euglenids, diplonemids, more dinoflagellates and *Perkinsus*, haptophytes, red algae and more.
> 3. **A new, larger family tree with four robustness tests.** It changes the "how many times" answer (see step 4).
> 4. **A second shared pocket change (Ser109→Trp)** turned up.

## Short version
1. **No stramenopile AdoMetDC has Glu178: 97 of 97 active enzymes** (Asn 54, His 32, Gln 9, Asp 2). The two sequences confirmed by FOLDTRACE structure and by sequence alignment agree on every stramenopile tested (31/31).
2. **Three other groups lack Glu178 too:**
   - **cryptophytes, all of them** (9/9, 7 species, Asn);
   - **kinetoplastids** (Ser) and the **euglenid** *Eutreptiella* (Asn);
   - one of the two AdoMetDC copies in **dinoflagellates and *Perkinsus*** (Asp, which keeps the negative charge).

   Haptophytes (32/32), Rhizaria, heteroloboseans, the diplonemid *Diplonema*, red algae, metamonads, animals, fungi and plants keep Glu.
3. **Family tree:** [[TREE_SHORT]]
4. **Published biochemistry fits, with the *T. cruzi* exception.**
   - All 6 sequenced enzymes measured as putrescine-activated (outside trypanosomes) keep Glu178.
   - The Glu→Gln mutation makes the human enzyme 4× more active without putrescine, and the worm (*C. elegans*) enzyme 100× more active without it.
   - *T. cruzi* has no Glu178 and is still activated, through Asp174. So the stramenopile prediction is reasonable but not guaranteed.
5. **Structure:** the diatom pocket is intact and still acidic, with Asn where the Glu was. Next to it, a **Trp** replaces human Ser109 and reaches toward the putrescine site. That swap is shared by 84% of the Glu-less lineages and almost nobody else (1%).

Figures:
- `Fig_tree_Glu178_expanded.png` (main tree, 187 enzymes)
- `Fig_tree_Glu178.png` (first-pass tree, 171 enzymes)
- `Fig_pocket_human_vs_stramenopile.png` (structure)

---

## Step 2 — Pull every stramenopile AdoMetDC ✅ (+ wider sampling)
**2a. UniProt (first pass):**
- I took every UniProt entry with Pfam **PF01536** (the canonical class-2 eukaryotic AdoMetDC) from stramenopiles, the rest of SAR and outgroups, plus 38 sequences from your FOLDTRACE run.
- That gave 248 proteins.

**2b. Wider sampling (new):**
- **Why:** UniProt misses most transcriptome-derived (MMETSP/TSA) sequences, and those are where cryptophytes, euglenids and many dinoflagellates live.
- **Searches:** NCBI protein (by name, within each target group) and UniParc (UniProt's archive, which still holds the transcriptome entries UniProt dropped).
- **Groups searched:** cryptophytes, euglenids, kinetoplastids, diplonemids, heteroloboseans, haptophytes, dinoflagellates, *Perkinsus*, chromerids, ciliates, Rhizaria, red algae, glaucophytes, non-ochrophyte stramenopiles, metamonads and apusomonads.
- **Result:** 332 new unique sequences. All went through the same pipeline: pairwise MAFFT to human, 16 mapped positions, and the engine check.
- **Contamination screen** (decided in advance). I dropped a sequence if its closest relative (≥50% identity) was in a *different* supergroup than its own and closer than anything in its own group. I also dropped records that UniProt pins on two different organisms. **12 removed:**
  - a "*Symbiodinium*" sequence 100% identical to the bicosoecid *Cafeteria* (culture contamination);
  - the ciliate *Tiarina* carrying a diatom sequence (prey);
  - the "dinotoms" *Durinskia* and *Kryptoperidinium*, which carry a diatom endosymbiont and whose copies sit with diatoms;
  - a *Heterosigma*/*Oxyrrhis* mixed record;
  - and a few others (full list in my working files).
- **Ciliates** (e.g. *Tetrahymena*) have only the prokaryotic-type PF02675 fusions, not the class-2 enzyme. That matches step 5.

**Final survey:** 339 active enzymes (sequence-identical duplicates removed). Of these, **97 are stramenopile**.

## Step 3 — Sequence check of the pocket ✅
**Residue at the human Glu178 position, active enzymes, wider survey (339):**

| Supergroup | Group | Proteins | Species | Glu kept | What replaced it |
|---|---|---|---|---|---|
| **Stramenopiles** | **Ochrophyta** | **42** | 32 | **0** | **Asn 42** |
| **Stramenopiles** | **Oomycota** | **41** | 39 | **0** | **His 32, Gln 9** |
| **Stramenopiles** | **Bigyra & other** | **14** | 8 | **0** | **Asn 12, Asp 2** ‡ |
| **Cryptophyta** | **Cryptophytes** | **9** | 7 | **0** | **Asn 7, Ala 2** |
| Discoba | Kinetoplastids | 7 | 6 | 0 | Ser 6, Tyr 1 |
| Discoba | Euglenid (*Eutreptiella*) | 1 | 1 | 0 | Asn 1 |
| Discoba | **Diplonemid (*Diplonema*)** | 1 | 1 | **1** | – |
| Discoba | Heteroloboseans | 9 | 6 | 9 | – |
| Alveolata | Dinoflagellates | 49 | 27 | 2 | Asp 28, Gln 11, Arg 3, Val 3, other 2 § |
| Alveolata | *Perkinsus* | 10 | 3 | 0 | Asp 10 |
| Alveolata | Apicomplexa | 10 | 8 | 3 | *Plasmodium* Ser 4, other 3 † |
| Alveolata | Chromerids | 3 | 2 | 2 | Ala 1 (likely alignment error) |
| Rhizaria | | 12 | 6 | 12 | – |
| Haptophyta | | 32 | 19 | **32** | – |
| Archaeplastida | Red algae | 22 | 18 | 19 | Asp 2 (Gracilariales), 1 gap |
| Archaeplastida | Green algae + land plants | 27 | 25 | 25 | Arg 1 (likely alignment error), 1 gap |
| Archaeplastida | Glaucophyte | 1 | 1 | 1 | – |
| Opisthokonta | Animals / fungi / other | 42 | 42 | 41 | Gln 1 (tapeworm) |
| Amoebozoa, Metamonada, Apusozoa | | 7 | 7 | 7 | – |

‡ The Asp cases are the bicosoecid *Halocafeteria* and one *Blastocystis* genome (subtype "Blastoise"). The *Blastocystis* one is odd: the other 6 *Blastocystis* have Asn, so it may be contamination.
§ Dinoflagellates have **two** AdoMetDC copies. One, often fused to an ODC (ornithine decarboxylase) domain, has Gln and sits with apicomplexans in the tree. The other, a standalone copy, has Asp and sits with stramenopiles (step 4).
† *Plasmodium* AdoMetDC is part of a ~1,400-aa fusion protein, so its calls are the least reliable in the set.

**What the table says:**
- **Every stramenopile, every cryptophyte, and every kinetoplastid/euglenid** lacks Glu178.
- **Their closest relatives keep it.** Haptophytes and Rhizaria are close relatives of stramenopiles and cryptophytes; heteroloboseans and *Diplonema* are close relatives of kinetoplastids.
- **Two methods agree.** FOLDTRACE structure calls and sequence alignment agree at position 178 for 125/129 overlapping proteins (31/31 stramenopiles). Over all 7 pocket positions they agree 830/874 times.
