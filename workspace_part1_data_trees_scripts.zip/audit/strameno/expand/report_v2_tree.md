
## Step 4 — Family tree: where, and how many times, was Glu178 lost? ✅ (re-done with wider sampling)

**What I ran:**
- **Proteins:** 187 active enzymes. I took the wider survey, removed near-duplicates, and capped very well-sampled groups so the tree stays balanced. Every cryptophyte, euglenozoan, *Perkinsus*, bigyran and deep-branching sequence was kept.
- **Alignment:** MAFFT L-INS-i, trimmed to 340 columns.
- **Tree:** IQ-TREE 2 with the best-fit model **Q.pfam+R7** (chosen fresh by BIC), 1,000 ultrafast bootstraps (UFBoot) + 1,000 SH-aLRT tests, and ancestral reconstruction at the Glu178 column.
- **Figure:** `Fig_tree_Glu178_expanded.png`.

**Result 1 — inside stramenopiles (unchanged and solid):**
- Stramenopiles now form a single group in the tree (weak support: UFBoot 68). Their ancestor had **Asn** (probability 0.999).
- Oomycetes later switched **Asn → His** (support 100). The downy mildew *Bremia* then switched His → Gln.
- Two bicosoecid-type tips switched Asn → Asp.
- **Glu was never regained anywhere** in the tree.

**Result 2 — the bigger finding: the Glu-less enzymes are one gene lineage**
- **What the tree shows:** the AdoMetDCs of **stramenopiles, cryptophytes, kinetoplastids + the euglenid, and a second copy found in dinoflagellates and *Perkinsus*** form **one group** (UFBoot 88).
  - That group does **not** follow the species tree: these organisms belong to 3 different supergroups.
  - Their close relatives in the species tree (haptophytes, Rhizaria, *Diplonema*, heteroloboseans, and the dinoflagellates' *other* copy, which sits with apicomplexans) all keep Glu and sit elsewhere.
- **The reconstruction** puts **a single Glu→Asn change at the base of this lineage** (probability 0.99). Each branch then made its own later swap:
  - Asn → Asp in the dinoflagellate/*Perkinsus* copy (charge restored);
  - Asn → His in oomycetes;
  - Asn → Ser in kinetoplastids.
- **Shared pocket clue:** a Trp in place of human **Ser109** is found in 84% of this lineage and in **1%** of everything else. In the diatom and brown-alga models, this Trp sits about 4 Å from where putrescine binds in human, which is roughly where Phe111's ring sits in human. In Ochrophyta Phe111 became Gly, so the Trp appears to take over its job.

**Robustness tests (are we fooling ourselves?):**

| Test | What it checks | Result |
|---|---|---|
| Remove all 35 pocket columns (within 8 Å of putrescine) and rebuild | Is the pocket itself pulling these sequences together? | Same lineage: stramenopiles + cryptophytes + kinetoplastids/euglenid (SH-aLRT 87 / UFBoot 64). The dinoflagellate/*Perkinsus* copy is its sister (85.5 / 72). |
| Remove the fast-evolving kinetoplastids and rebuild | Long-branch artifact? | Same lineage (UFBoot 85), still one Glu→Asn at its base. The euglenid now sits next to cryptophytes. |
| AU test: put cryptophytes back with haptophytes | Could cryptophytes have lost Glu on their own? | ΔlnL 38, **p = 0.025** (rejected) |
| AU test: put kinetoplastids + euglenid back with *Diplonema* | Could Euglenozoa have lost it on their own? | ΔlnL 55, **p = 0.001** (rejected) |
| AU test: put the dinoflagellate/*Perkinsus* Asp copy with the alveolate copy | Is it just an ordinary alveolate duplicate? | ΔlnL 34, **p = 0.003** (rejected) |
| AU test: all three moved back (species-tree arrangement) | Separate losses everywhere? | ΔlnL 99, **p = 0.0001** (rejected) |
| Same four AU tests with the pocket columns removed | Is the rejection driven by the pocket? | Still rejected: p = 0.034 / 0.012 / 0.002 / 0.0006 |

*(Each alternative tree was built by moving that group to its species-tree neighbour in the best tree, then re-optimizing under a constraint. The AU test used 10,000 replicates.)*

**So how many times was Glu178 lost? The answer now:**
- **In the best-supported picture, once.** A single Glu→Asn change happened in one AdoMetDC gene lineage. That lineage is now carried by stramenopiles, cryptophytes, kinetoplastids/euglenids, and (as an extra copy) dinoflagellates and *Perkinsus*.
- **The alternative of separate losses in each group** (at least 4 events) is **statistically rejected**, with or without the pocket residues.
- **Apart from that lineage**, only a handful of single-species changes occur: one tapeworm (Gln), plus one red alga and one mite that swapped Glu for Asp and so kept the charge. Separately, dinoflagellates' own alveolate copy has Gln (one event, support 100).
- **Glu was never regained.**

**What this probably means (stated carefully):**
- A gene lineage spread across unrelated eukaryotes usually means **horizontal gene transfer** (the gene moved between organisms).
- The other option is an **ancient gene duplication followed by losses**. Dinoflagellates still carrying *both* types would fit either one.
- **This single-gene analysis can't tell which, or which direction the gene moved.** That has to be said plainly in a paper.
- **For our story,** stramenopiles carry the putrescine-sensor-less AdoMetDC because their gene belongs to this special lineage, not because each group independently reinvented it.

**Earlier first-pass tree (171 enzymes, UniProt only)**, kept for the record (`Fig_tree_Glu178.png`):
- It showed the same grouping, but the AU tests could only reject all three species-tree arrangements *together*, not individually.
- Adding cryptophytes, *Diplonema*, more dinoflagellates, *Perkinsus* and more Bigyra made each individual test significant.

**Honest limits of the tree part:**
- **It's one gene.** Support for the deepest node of the lineage is moderate (UFBoot 85–88 with the pocket; 64 without it).
- **The AU tests** depend on how well the alternative trees were optimized. Each got a constrained search starting from the best tree.
- **Sampling still has gaps.** Katablepharids, telonemids and centrohelids returned no AdoMetDC sequences in NCBI name searches. Some sequences come from transcriptomes, which I screened for contamination but cannot fully guarantee.
- ***Diplonema* is a single sequence.** It keeps Glu and groups with heteroloboseans, not with kinetoplastids.
