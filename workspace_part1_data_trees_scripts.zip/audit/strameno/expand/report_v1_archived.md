# Stramenopile AdoMetDCs lost the putrescine sensor (Glu178): steps 2–6 results
*Tui, 5 Nov 2026. This is my computational analysis, not Marc's protocol. I used your FOLDTRACE run read-only and changed nothing in your project folder. No wet lab. Step 1 is in `stramenopile_Glu178_step1_results.md`.*

## Short version
1. **The pattern holds on all of UniProt, not just the FOLDTRACE top 1,000.** Every active stramenopile AdoMetDC lacks Glu178: **87 of 87** (91 of 91 including fragments). Ochrophyta and Bigyra have **Asn**; oomycetes have **His** (32) or **Gln** (9). Almost every other major eukaryote group with an active enzyme keeps Glu.
2. **Two independent methods agree.** For the 131 proteins in both datasets, the sequence-alignment and FOLDTRACE structural calls at position 178 agree **125 of 129** times (**31 of 31** stramenopiles). Across all 7 pocket positions they agree 830 of 874 times.
3. **Published biochemistry fits, with one exception we must state.** All 6 sequenced enzymes measured as putrescine-*activated* outside trypanosomes keep Glu178. Changing this Glu to Gln makes the enzyme work without putrescine, both in humans (Bale 2008, Table 4; source data Stanley 1994) and in *C. elegans* (Ndjonka 2003). The exception is *T. cruzi*: it has Ser here and is *still* activated, through Asp174. So the stramenopile prediction is **reasonable but not guaranteed**.
4. **Family tree:** **inside stramenopiles, Glu178 was lost once, early.** Asn came first; oomycetes later switched Asn→His, and one *Phytophthora*/downy-mildew group then switched His→Gln. Glu was **never regained** anywhere in the tree. Whether that same loss is shared with kinetoplastids/euglenids, the cryptophyte *Guillardia* and dinoflagellates (which the gene tree groups with stramenopiles) **is not resolved**. The robustness tests say this single-gene tree can't decide (details in step 4).
5. **Structure:** the diatom pocket is intact and still acidic, with a neutral Asn where the Glu was: the same kind of change as the human E178Q mutant. The oomycete pocket is partly filled by its own side chains (His, Asn, Tyr).

Figures: `Fig_pocket_human_vs_stramenopile.png` (structure), `Fig_tree_Glu178.png` (tree). 

---

## Step 2 — Pull every stramenopile AdoMetDC from UniProt ✅
- **Query:** UniProt entries carrying Pfam **PF01536** (the canonical eukaryotic, class-2 AdoMetDC) in Stramenopiles (taxon 33634), plus other SAR (Alveolata 33630, Rhizaria 543769), plus outgroups across the eukaryote tree. I also added the 38 proteins from your FOLDTRACE run that UniProt search hadn't returned, using the sequences in the AlphaFold model files.
- **Result:** **248 unique proteins**: 81 + 53 + 81 from UniProt and 38 from FOLDTRACE, with 5 duplicates removed. That includes **91 stramenopile proteins** (45 Ochrophyta from at least 7 classes, 42 Oomycota, 4 Bigyra). Step 1 had 31.
- Every sequence length was checked against UniProt's stated length (all match). Sequences I typed in by hand were checked against UniProt's MD5 checksum (all match).

## Step 3 — Sequence check of the pocket in every protein ✅
- Each protein was aligned to human AdoMetDC (P17707) with **MAFFT L-INS-i**. I read off 16 positions: the 8 pocket residues (L13, E15, F111, D174, T176, E178, E256, F285) and the catalytic "engine" (S68, C82, H243, plus S229, E67, F7, F223, E247).
- "Active" = engine intact (Ser68 + Cys82 + His243). That gives 208 active proteins, 34 partial or fragments, and 6 dead copies.

**Residue at the human Glu178 position, active enzymes only (208):**

| Supergroup | Group | n | Glu kept | What replaced it |
|---|---|---|---|---|
| **Stramenopiles** | **Ochrophyta** | **42** | **0** | **Asn 42** |
| **Stramenopiles** | **Bigyra** | **4** | **0** | **Asn 4** |
| **Stramenopiles** | **Oomycota** | **41** | **0** | **His 32, Gln 9** |
| Alveolata | Dinoflagellates | 8 | 0 | Asp 6, Gln 2 |
| Alveolata | *Perkinsus* | 1 | 0 | Asp 1 |
| Alveolata | Apicomplexa | 10 | 3 | *Plasmodium*: Ser 4, Asn/Ile/Phe 1 each † |
| Alveolata | Chromerids | 2 | 1 | Ala 1 ‡ |
| Rhizaria | | 3 | 3 | – |
| Opisthokonta | Animals | 24 | 23 | Gln 1 (tapeworm *Rodentolepis*) |
| Opisthokonta | Fungi | 13 | 13 | – |
| Opisthokonta | Other opisthokonts | 5 | 5 | – |
| Amoebozoa | | 2 | 2 | – |
| Archaeplastida | Land plants | 9 | 8 | 1 alignment gap |
| Archaeplastida | Green algae | 18 | 17 | Arg 1 (*Raphidocelis*) ‡ |
| Archaeplastida | Red algae | 7 | 7 | – |
| Haptophyta | | 8 | 8 | – |
| Cryptophyta | *Guillardia* | 1 | 0 | Asn 1 |
| Discoba | Euglenid (*Eutreptiella*) | 1 | 0 | Asn 1 |
| Discoba | Kinetoplastids | 4 | 0 | Ser 4 |
| Discoba | Heteroloboseans | 4 | 4 | – |
| Metamonada | Parabasalid | 1 | 1 | – |

† *Plasmodium* AdoMetDC is one domain of a ~1,400-aa ODC/AdoMetDC fusion, and these alignments are the least reliable in the set.
‡ Probably an alignment error. The multiple alignment (step 4) puts Glu here, and for *Vitrella* FOLDTRACE also says Glu.

**What the table says:**
- **Stramenopiles are the only large group in which every member lost the charge.** Alveolates are the closest relatives in SAR. Their dinoflagellates and *Perkinsus* mostly have **Asp**, so they keep a negative charge at this spot. Rhizaria keep Glu.
- **The only other groups without Glu are small and scattered:** kinetoplastids (Ser), the euglenid *Eutreptiella* (Asn), the cryptophyte *Guillardia* (Asn), *Plasmodium*, and one tapeworm.

**Two independent methods (FOLDTRACE structure vs sequence alignment):** 131 proteins appear in both datasets. At position 178, the calls agree **125 / 129** times (2 not callable). All **31 / 31** stramenopile calls agree. The 4 disagreements are a chromerid, a tapeworm, a mouse fragment and a mite, none of them stramenopiles. Across all 7 pocket positions the calls agree **830 / 874** times (95%). Most of the disagreements are at the more variable positions D174, T176, F285 and F111.

## Step 4 — Family tree: where, and how many times, was Glu178 lost? ✅
**What I ran:**
- **Which proteins went into the tree:** 171 active enzymes. I removed *Plasmodium* (giant fusion protein), sequences under 28% identity to human, fragments under 250 aa, and near-duplicates (>92% identical within the same group).
- **Alignment:** MAFFT L-INS-i, trimmed to the 344 columns with ≤50% gaps.
- **Tree:** IQ-TREE 2 with the best-fit model **LG+R6** (by BIC), 1,000 ultrafast bootstraps (UFBoot) + 1,000 SH-aLRT tests.
- **Ancestral reconstruction:** marginal ancestral-state reconstruction at the Glu178 column.
- **Then two robustness checks** (below).

**Figure:** `Fig_tree_Glu178.png`. Branches are coloured by the reconstructed residue; uniform groups are collapsed into wedges.

**Result A — inside stramenopiles (solid; same answer on every tree I tried):**
- **The stramenopile ancestor already had Asn** (posterior probability 0.99–1.0). Ochrophyta and Bigyra kept it.
- **Oomycetes switched Asn → His** at their base (probability 0.999; the oomycete group itself has 99.9 SH-aLRT / 100 UFBoot support).
- **One oomycete subgroup then switched His → Gln** (UFBoot 99): part of *Phytophthora* including *P. infestans*, plus the downy mildews *Plasmopara* and *Bremia*. Other *Phytophthora* keep His.
- **So the stramenopile pattern is one early event, not 87 separate ones,** and **Glu was never regained** (zero reversals anywhere in the tree).

**Result B — the surprise, NOT resolved:**
- **What the gene tree shows:** stramenopile AdoMetDCs sit in one group (UFBoot 95, SH-aLRT 75) with the *other* lineages that lack Glu178:
  - kinetoplastids + the euglenid *Eutreptiella* + the cryptophyte *Guillardia*. This trio is itself very strongly grouped (98.7 / 100).
  - dinoflagellates + *Perkinsus*, which have Asp (99.3 / 100).
- **Taken literally**, the reconstruction puts **one** Glu→Asn change at the base of that whole group. Asp (dinoflagellates), His (oomycetes) and Ser (kinetoplastids) would all come later.
- **But these organisms belong to 3 different supergroups** (SAR, Discoba, Cryptista). If the grouping were real, it would mean the gene moved between lineages. If not, it is a tree-building artifact.
- **Check 1 — is the pocket itself pulling them together?** I deleted all **35 columns within 8 Å of putrescine** (positions taken from the 1MSV crystal structure) and rebuilt the tree. The *same* 75-protein group appears, but its support falls from UFBoot 95 to **63** (SH-aLRT 64). So part of the support came from the pocket residues; the rest of the protein only weakly favours the grouping.
- **Check 2 — does the species-tree arrangement fit the data just as well? (AU test, 10,000 replicates)**

| Tree | Δ log-likelihood | p-AU | Rejected? |
|---|---|---|---|
| Best (unconstrained) tree | 0 | 0.66 | – |
| Stramenopiles forced to be one group | 1.8 | 0.58 | no |
| Alveolates forced to be one group | 22.8 | 0.18 | no |
| Discoba (kinetoplastids + euglenid + heteroloboseans) forced together | 40.6 | 0.066 | no (borderline) |
| All three species-tree groupings at once | 53.5 | **0.004** | **yes** |

**What this means:**
- Each species-tree grouping on its own is compatible with the data. The data only reject all three together.
- So this one gene **cannot tell us** whether stramenopiles share their loss with the euglenozoans, the cryptophyte and the dinoflagellates, or whether those groups lost Glu178 on their own.
- On the tree constrained to the species groupings, the reconstruction gives **separate changes**: Asn in stramenopiles; Ser/Asn in Euglenozoa; Asp (charge kept) in dinoflagellates + *Perkinsus*.

**So how many times was Glu178 lost? The honest answer:**
- **Within stramenopiles: once,** early, as Glu→Asn. His and Gln in oomycetes are later changes. This is robust.
- **Across eukaryotes:**
  - **Gene tree:** a minimum of **1 deep loss** plus 2 single-species changes (tapeworm *Rodentolepis* Gln; dinoflagellate *Polarella* Gln).
  - **Accepted species tree:** the negative charge was lost **at least 3 separate times** (stramenopiles, Euglenozoa, cryptophytes), plus a Glu→Asp swap in dinoflagellates/*Perkinsus*, plus *Plasmodium* and the single-species cases.
  - **The data can't yet choose between these two pictures.**
- **Corrections to step 3:** two "losses" in the step-3 table are probably alignment errors. In *Vitrella* (Ala) and *Raphidocelis* (Arg), the pairwise alignment called a non-Glu residue, but the 171-protein multiple alignment puts **Glu** in that column. For *Vitrella*, FOLDTRACE also says Glu. The figure uses the multiple-alignment calls.

## Step 5 — Check the prediction against enzymes whose putrescine response has been measured ✅
I looked up every AdoMetDC whose putrescine response has been measured, pulled its sequence from UniProt, and mapped it with the same pipeline. Abstracts and full text were checked on PubMed/PMC.

**First, the mapping reproduces published residue numbers:**
- *C. elegans*: T192, E194, E274 match Ndjonka 2003 exactly.
- Potato: R18, R114, V181, H294 match Bennett 2002 exactly.
- *T. cruzi*: 9 of 10 residues named in Clyne 2002 / Beswick 2006 match (F7, R13, E15, I80, D174, S178, T245, E256, F285). The one miss is Ser111, where our alignment is 2 residues off because of a nearby gap. I note this for the F111 calls in trypanosomes; the stramenopile F111 calls are backed by FOLDTRACE.
- The *Acanthamoeba castellanii* peptide that Hugo & Byers sequenced (UniProt P34039) matches the N-terminus of L8GRS6 exactly. So L8GRS6 is the protein they purified.

| Organism (UniProt) | Measured putrescine response | Source (PMID) | Residue at 178 | Fits the rule? |
|---|---|---|---|---|
| Human (P17707) | Activated (processing + activity). **E178Q: ~4× WT activity without putrescine, no further stimulation** | Stanley 1994 (8132508); Bale 2008 Table 4 (19053272) | **E** | ✅ |
| Yeast *S. cerevisiae* (P21182) | "putrescine-activated" | Pegg & Jacobs 1983 (6351843); Karvonen 1985 (3933487) | **E**213 | ✅ |
| *Neurospora crassa* (Q9Y7F3) | Putrescine **absolutely required** for activity | Hoyt 2000 (10852489) | **E**258 | ✅ |
| *C. elegans* (O02655) | **350-fold** stimulated. **E194Q (= human E178Q): 100-fold higher activity with no activator** | Ndjonka 2003 (12674502) | **E**194 | ✅ key precedent |
| *Onchocerca volvulus* (Q27883) | 15-fold stimulated | Da'dara 1998 (9879883) | **E**196 | ✅ |
| *Acanthamoeba castellanii* (L8GRS6) | 2-fold stimulated (weak) | Hugo & Byers 1993 (8216217) | **E**202 | ✅ |
| *Acanthamoeba culbertsoni* | Strongly activated | Gupta 1987 (3600699) | no sequence available | – |
| Potato (Q04694), *Arabidopsis* (Q96286) | **Not** stimulated; fully active alone | Bennett 2002 (12463749) | **E**185 / **E**182 | ✅ different route: Glu kept, but Arg/Lys/His built into the pocket mimic putrescine |
| *P. falciparum* (Q9Y1L5) | AdoMetDC domain **not** stimulated | Wrenger 2001 (11390378) | **S** | ✅ |
| ***T. cruzi* (O76240)** | **Stimulated 11–27-fold**; binding needs **Asp174 only**; mutating Ser178 has no effect | Clyne 2002 (12403622); Beswick 2006 (16784231) | **S**194 | ❌ **exception** |
| *Tetrahymena* | **Not** stimulated | Pösö 1975 (813467) | n/a: no class-2 (PF01536) enzyme in UniProt for *Tetrahymena*. Its only AdoMetDCs are 6 small prokaryotic-type (PF02675) domains fused to spermidine synthase | ✅ explained by enzyme class, not residue 178 |

**What this means for the prediction (stated carefully):**
- **Glu178 marks the activated enzymes.** All 6 measured, putrescine-activated enzymes outside trypanosomes keep it.
- **Removing Glu178 has a known effect in two species.** In the human enzyme, E178Q gives ~4× wild-type activity with no putrescine, and putrescine adds nothing. In the worm enzyme, the equivalent E194Q gives 100× higher activity with no activator. Stramenopiles carry the natural version of this change. Ochrophyta and Bigyra have Asn, a close relative of Gln.
- **But *T. cruzi* shows another possible outcome.** It lacks Glu178 and is still putrescine-activated, because Asp174 alone binds putrescine. Stramenopiles keep Asp174 (Glu in oomycetes) and Glu256. So some putrescine binding could remain.
- **The honest prediction:** stramenopile AdoMetDC should have **high activity without putrescine and little or no extra stimulation**, like E178Q. A *T. cruzi*-like residual response cannot be ruled out from sequence alone. The experiment (activity ± putrescine) decides between them.
- **Correction to step 1:** I had listed *Tetrahymena* (Pösö 1975) as a possible validation point. It isn't one. *Tetrahymena* has no class-2 enzyme at all, so its insensitivity tells us nothing about residue 178.

## Step 6 — Structure figure: human vs diatom pocket ✅
- **Method:** human crystal structure 1MSV (putrescine bound, chain A) vs the AlphaFold models already in your FOLDTRACE run. I superposed each pair on the residues near the pocket, refining the fit iteratively. Core RMSD: diatom *Phaeodactylum* 0.95 Å, brown alga *Ectocarpus* 0.76 Å, *Cafeteria* 0.83 Å, oomycete *Hyaloperonospora* 0.78 Å. pLDDT at the pocket residues is 80–98, so the models are confident there.
- **Figure:** `Fig_pocket_human_vs_stramenopile.png`. A = human, B = diatom, C = oomycete.

**Closest approach of each pocket residue to putrescine's nitrogens (Å). AlphaFold confidence (pLDDT) in brackets:**

| Human residue (1MSV) | Human | Diatom *Phaeodactylum* | Brown alga *Ectocarpus* | *Cafeteria* (Bigyra) | Oomycete *Hyaloperonospora* |
|---|---|---|---|---|---|
| L13 | 3.4 | Thr12 3.6 (97) | Thr56 3.9 (98) | Thr32 4.1 (98) | Asn29 3.1 (98) |
| E15 | 2.8 | Glu14 3.2 (96) | Glu58 2.6 (97) | Glu34 2.6 (97) | Glu31 2.7 (98) |
| F111 | 4.5 | **Gly124** 5.8 (95) | **Gly148** 5.7 (95) | Cys124 4.5 (96) | Asn121 3.2 (96) |
| D174 | 2.9 | Asp194 3.7 (80) | Asp210 4.1 (83) | Asp187 4.2 (87) | Glu199 3.6 (78) |
| T176 | 2.7 | Val196 3.2 (93) | Thr212 3.1 (95) | Thr189 3.0 (94) | Thr201 3.0 (92) |
| **E178** | 5.2 | **Asn198** 7.2 (95) | **Asn214** 6.8 (98) | **Asn191** 5.0 (98) | **His203** 3.7 (96) |
| E256 | 5.0 | Glu289 5.6 (97) | Glu292 5.3 (98) | Glu352 4.6 (98) | Glu282 4.8 (98) |
| F285 | 4.5 | Met318 3.0 (88) | Phe321 4.7 (93) | Phe381 4.6 (92) | Tyr311 4.3 (88) |

**Reading it:**
- **Ochrophyta and Bigyra (diatom, brown alga, *Cafeteria*):** the pocket is still there and still lined with acid (Glu15, Asp174, Glu256). The Glu178 spot holds a **neutral Asn**. No side chain fills the space where putrescine sits. In human 1MSV, Glu178 contacts putrescine through a bridging water (Bale 2008), which fits its 5.2 Å distance. Bale also reports that E178Q *lacks* that bridging water, which is why putrescine no longer activates it. The diatom geometry looks like that mutant, not like the plant solution. **Gly** at F111 (Ochrophyta) removes one of the two aromatic walls, so the pocket may be roomier.
- **Oomycete:** the pocket is **partly filled by the protein's own side chains**. His203 sits at the Glu178 spot and points in (3.7 Å). Asn121 replaces Phe111, and a Tyr (Tyr354, outside the 8 mapped positions) has its OH 2.1 Å from where putrescine's nitrogen sits in human. That's closer to the plant idea (a built-in side chain occupying the activator site), so **oomycetes may differ from diatoms**. This is a possible sub-finding.
- **Limits:** AlphaFold models have no ligand and no water. This shows pocket *shape and chemistry*, not binding.

## Novelty update
- **No change from step 1:** I still find no paper reporting that stramenopile AdoMetDCs lack the putrescine sensor, and no survey of this residue across eukaryotes.
- **Michael 2011, now separated with data.** In UniProt, stramenopiles carry **98** proteins with the *prokaryotic-type* AdoMetDC domain (PF02675). 93 are from diatoms, 79 are fused to spermidine synthase, the median length is 748 aa (up to 2,477), and **none** also carries the canonical PF01536 domain. These are the "fusion machines" family Michael 2011 describes. Our enzyme (PF01536) is a different protein family. Class-1/PF02675 domains have no putrescine pocket at all (Bale 2008 discussion), so they can't speak to Glu178.
- **Still to read:** Michael 2011 (Marc has the DOI) to confirm it doesn't discuss the canonical enzyme's pocket.

## Honest limits
- **This is a prediction from sequence and structure.** No stramenopile AdoMetDC has had its putrescine response measured. *T. cruzi* proves that losing Glu178 doesn't automatically mean losing putrescine activation.
- **UniProt coverage is uneven.** It's heavy on diatoms and *Phytophthora*-like oomycetes. Some stramenopile classes have only 1–2 proteins, and several are TSA-derived (transcriptome) entries.
- **The gene tree is a single-gene tree with 344 alignable columns.** The deep branches are weakly resolved (see step 4).
- **Plasmodium calls** come from a giant fusion protein and are the least reliable.

## Where this leaves the paper
**What is solid enough to write up now (all computational):**
1. **A stramenopile-wide replacement of the putrescine-sensor residue.** All 87 active enzymes lack it, confirmed by two independent methods: FOLDTRACE structure calls and sequence alignment.
2. **A single early origin within stramenopiles.** Asn came first; oomycetes made later His/Gln changes; Glu was never regained.
3. **A mechanistic analogy with published precedent.** The natural stramenopile pocket looks like the characterized activator-independent mutants, human E178Q and worm E194Q.
4. **A check against every published putrescine-response measurement I could find.** 6 of 6 activated, sequenced, non-trypanosome enzymes keep Glu. *T. cruzi* is the stated exception.
5. **A clean separation from Michael 2011's fusion family**, backed by Pfam data.
6. **The prediction stated plainly:** stramenopile AdoMetDC should be active without putrescine. The experiment (*Phaeodactylum* enzyme ± putrescine) is proposed as future work.

**The open question that could make it more interesting (not a claim yet):** is the stramenopile Asn shared with euglenozoans, cryptophytes and dinoflagellates (a gene that moved between lineages), or did they each get there separately? Testing it needs:
- more sequences from those groups (more cryptophytes, euglenids, dinoflagellates, haptophytes);
- a gene-tree vs species-tree reconciliation;
- possibly intron positions as independent evidence.

**What I'd do next (all computational, no lab):**
- [ ] Add more cryptophyte, euglenid, dinoflagellate and haptophyte AdoMetDCs (e.g. from the transcriptome-based TSA entries) and re-run the tree and AU test.
- [ ] Repeat the tree without kinetoplastids (fast-evolving) to test long-branch attraction.
- [ ] Make a clean "Figure 1" for a paper: species-tree cartoon + residue-178 column + pocket panel.
- [ ] Write a 1-page summary for Marc.
- [ ] Michael 2011 full text (from Marc) to lock novelty.
- [ ] Ask Luke/Maddie which journal or format they used.
