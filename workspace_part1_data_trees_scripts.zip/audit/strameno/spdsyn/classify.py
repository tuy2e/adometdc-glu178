import json, collections, sys
from Bio import Align
from Bio.Align import substitution_matrices
recs=json.load(open('uniprot_apt_dom.json'))
allr={x['acc']:x for x in json.load(open('uniprot_apt.json'))}
REF={'SPDS':['P19623','Q12074','Q9ZUB3','Q9XY92'],'SPMS_plant_yeast':['Q94BN2','Q12455'],'SPMS_animal':['P52788'],'TSPMS':['Q9S7X6']}
al=Align.PairwiseAligner(); al.substitution_matrix=substitution_matrices.load('BLOSUM62'); al.open_gap_score=-11; al.extend_gap_score=-1; al.mode='local'
def ident(a,b):
    aln=al.align(a,b)[0]; m=0; L=0
    for (s0,s1),(t0,t1) in zip(*aln.aligned):
        for i in range(s1-s0):
            L+=1; m+= a[s0+i]==b[t0+i]
    return m/max(1,min(len(a),len(b))), L
out=[]
for x in recs:
    best=None
    for cls,accs in REF.items():
        for r in accs:
            idn,L=ident(x['dseq'],allr[r]['seq'])
            if best is None or idn>best[0]: best=(idn,cls,r,L)
    x['best']=dict(id=round(best[0],3),cls=best[1],ref=best[2],alen=best[3])
    out.append(x)
json.dump(out,open('uniprot_apt_cls.json','w'))
c=collections.Counter((x['best']['cls'], x['best']['id']>=0.35) for x in out); print(c)
